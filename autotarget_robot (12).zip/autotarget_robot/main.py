"""
Top-level control script for the AutoTarget robot.

Two phases, matching the competition structure:

  1. CALIBRATION (up to 5 minutes): the camera is fixed, so just watch for
     the goal in its view and lock in its bearing (median of several sightings).

  2. LIVE TRIAL: continuously track the incoming ball's bearing with the
     camera and update the panel angle in real time using the reflection
     formula, so the ball gets redirected toward the (now-known) goal
     bearing no matter which direction it happens to arrive from.

Run with `python3 main.py --sim` to exercise the whole flow on a laptop
with no camera/servo hardware attached (uses a fake camera feed and
prints servo commands instead of moving a real motor) -- useful for
testing the control logic and timing before deploying to the Pi.
"""

import argparse
import time

import config
import camera_tracker
import geometry
import reflection
from servo_control import PanelServo


def calibrate(cap, panel: PanelServo) -> float:
    """
    Find the goal's bearing with the FIXED camera and return it (degrees,
    + = right of the camera centerline, which is the robot's forward axis).

    The camera does not move, so the goal must be inside its field of view
    (about +-CAMERA_HFOV_DEG/2). We just watch the feed, collect
    CALIBRATION_SAMPLES sightings of the goal and lock in their median
    (robust to a stray bad frame). Gives up after CALIBRATION_TIMEOUT_S.
    """
    print("Calibration: looking for the goal in the fixed camera view...")
    deadline = time.time() + config.CALIBRATION_TIMEOUT_S
    samples = []

    while time.time() < deadline:
        frame, outputs = camera_tracker.read_frame(cap)
        if frame is not None:
            det = camera_tracker.get_goal_detection(frame, outputs)
            if det is not None:
                # pixel -> bearing seen from the panel pivot (camera offset,
                # height, pitch and yaw all handled in geometry.py)
                bearing = geometry.goal_bearing(det, frame)
                samples.append(bearing)
                print(f"  goal sightings: {len(samples)}/{config.CALIBRATION_SAMPLES}", end="\r")
                if len(samples) >= config.CALIBRATION_SAMPLES:
                    break

    if len(samples) < config.CALIBRATION_SAMPLES:
        raise RuntimeError(
            f"Calibration timed out: goal seen in only {len(samples)} frames. The camera "
            "is fixed, so the goal patch must be inside its view. Check the camera "
            "aim, and GOAL_HSV_* in config.py against the real goal color "
            "(tools/hsv_tuner.py)."
        )

    samples.sort()
    goal_bearing = samples[len(samples) // 2] if len(samples) % 2 else \
        0.5 * (samples[len(samples) // 2 - 1] + samples[len(samples) // 2])
    spread = samples[-1] - samples[0]
    print(f"\nGoal locked at {goal_bearing:+.1f} deg (spread {spread:.1f} deg over {len(samples)} sightings).")
    if spread > config.CALIBRATION_MAX_SPREAD_DEG:
        print(f"WARNING: sightings spread {spread:.1f} deg > {config.CALIBRATION_MAX_SPREAD_DEG} deg; "
              "check for glare, a moving robot/camera, or a second red object in view.")
    return goal_bearing


def run_live_trial(cap, panel: PanelServo, goal_bearing_deg: float):
    """
    Main real-time loop: track the ball, compute the panel angle via
    the reflection formula, and command the servo -- repeatedly, so the
    panel keeps adjusting as the ball's apparent bearing changes while
    it approaches.
    """
    print(f"Live trial started. Goal bearing locked at {goal_bearing_deg:+.1f} deg.")
    period = 1.0 / config.LIVE_LOOP_HZ
    smoothed_bearing = None

    try:
        while True:
            loop_start = time.time()

            frame, outputs = camera_tracker.read_frame(cap)
            if frame is not None:
                det = camera_tracker.get_ball_detection(frame, outputs)
                ball_bearing = geometry.ball_bearing(det, frame) if det is not None else None

                if ball_bearing is not None:
                    if smoothed_bearing is None:
                        smoothed_bearing = ball_bearing
                    else:
                        a = config.BEARING_SMOOTHING_ALPHA
                        smoothed_bearing = a * ball_bearing + (1 - a) * smoothed_bearing

                    panel_normal = reflection.panel_angle_from_bearings(
                        smoothed_bearing, goal_bearing_deg
                    )
                    servo_angle = reflection.servo_angle_from_panel_normal(
                        panel_normal, config.SERVO_CENTER_DEG, config.PANEL_DIRECTION
                    )
                    panel.set_angle(servo_angle)

                    print(
                        f"ball={smoothed_bearing:+6.1f} deg  "
                        f"panel_normal={panel_normal:+6.1f} deg  "
                        f"servo={panel.get_last_angle():6.1f} deg",
                        end="\r",
                    )
                # If the ball isn't currently visible, hold the last
                # commanded angle rather than snapping back to center --
                # avoids jittering the panel every time the ball briefly
                # drops out of the color threshold.

            elapsed = time.time() - loop_start
            time.sleep(max(0.0, period - elapsed))

    except KeyboardInterrupt:
        print("\nLive trial stopped by user.")


def main():
    parser = argparse.ArgumentParser(description="AutoTarget robot control")
    parser.add_argument(
        "--sim", action="store_true",
        help="Run without real hardware: prints servo commands, still needs a camera "
             "(or webcam) for the vision pipeline unless you also stub that out."
    )
    args = parser.parse_args()

    cap = camera_tracker.open_capture()
    panel = PanelServo(simulate=args.sim)
    panel.center()

    try:
        goal_bearing_deg = calibrate(cap, panel)
        run_live_trial(cap, panel, goal_bearing_deg)
    finally:
        cap.stop()
        panel.center()


if __name__ == "__main__":
    main()
