"""
Pixel -> bearing as seen from the PANEL PIVOT (pure math, no hardware).

The camera is not at the panel pivot: it is some distance to the side / in
front, at some height, possibly pitched down and turned. A ball that is
dead ahead of the pivot therefore appears off-centre in the camera, and by an
amount that depends on how far away it is (parallax). The camera alone cannot
tell range, but both targets lie on (or at a known height above) the FLOOR,
so a pixel's row tells us the range: intersect the pixel's ray with the floor.

Steps for a pixel (cx, cy):
  1. pinhole ray in the camera frame (x right, y down, z forward)
  2. tilt it by CAMERA_PITCH_DEG into a level frame (x right, y fwd, z up)
  3. intersect with the plane at the target's height  -> floor point (right, fwd)
  4. rotate by CAMERA_YAW_OFFSET_DEG into the robot frame
  5. add the camera's position relative to the pivot
  6. bearing = atan2(right, forward)   (+ = right of robot-forward)

If the ray never reaches the floor (pixel at/above the horizon) or the hit is
beyond GEOMETRY_MAX_RANGE_M, it falls back to camera-axis bearing + yaw, with
no parallax correction (returns used_floor=False so callers can tell).
"""

import math

import config


def focal_length_px(frame_w):
    return (frame_w / 2.0) / math.tan(math.radians(config.CAMERA_HFOV_DEG) / 2.0)


def floor_point(cx, cy, frame_w, frame_h, target_height_m):
    """(right_m, forward_m) from the camera, in the camera's own yawed frame,
    or None if the ray doesn't hit the target-height plane in range."""
    f = focal_length_px(frame_w)
    xn = (cx - frame_w / 2.0) / f
    yn = (cy - frame_h / 2.0) / f                      # down-positive
    p = math.radians(config.CAMERA_PITCH_DEG)
    ry = -yn * math.sin(p) + math.cos(p)               # forward component
    rz = -yn * math.cos(p) - math.sin(p)               # up component (negative = downward)
    dz = target_height_m - config.CAMERA_HEIGHT_M      # negative when target is below camera
    if rz >= -1e-6 or dz >= 0:
        return None
    t = dz / rz
    right, fwd = t * xn, t * ry
    if fwd <= 0 or math.hypot(right, fwd) > config.GEOMETRY_MAX_RANGE_M:
        return None
    return right, fwd


def pixel_to_bearing(cx, cy, frame_w, frame_h, target_height_m):
    """Bearing (deg, + = right) of the target from the pivot, plus whether the
    floor geometry was used. Returns (bearing_deg, used_floor)."""
    yaw = config.CAMERA_YAW_OFFSET_DEG
    f = focal_length_px(frame_w)
    axis_bearing = math.degrees(math.atan((cx - frame_w / 2.0) / f))

    pt = floor_point(cx, cy, frame_w, frame_h, target_height_m) if config.USE_FLOOR_GEOMETRY else None
    if pt is None:
        return axis_bearing + yaw, False

    right, fwd = pt
    psi = math.radians(yaw)
    x = right * math.cos(psi) + fwd * math.sin(psi)
    y = -right * math.sin(psi) + fwd * math.cos(psi)
    x += config.CAMERA_POS_RIGHT_M
    y += config.CAMERA_POS_FORWARD_M
    return math.degrees(math.atan2(x, y)), True


def detection_bearing(det, frame, target_height_m):
    """Convenience: Detection (cx, cy, source) + frame array -> pivot bearing."""
    h, w = frame.shape[:2]
    return pixel_to_bearing(det.cx, det.cy, w, h, target_height_m)[0]


def ball_bearing(det, frame):
    return detection_bearing(det, frame, config.BALL_RADIUS_M)


def goal_bearing(det, frame):
    return detection_bearing(det, frame, config.GOAL_HEIGHT_M)
