"""
Interactive HSV threshold tuner for the ball / goal color-threshold path.

Live camera (on the Pi, over VNC or a monitor):
    python3 tools/hsv_tuner.py

Test on a saved picture instead (no camera needed):
    python3 tools/hsv_tuner.py --image some_photo.jpg

Drag the six sliders until ONLY the object you care about is white in the
"mask" window, then press 'p' to print the values in config.py format
(and 'q' to quit). Do this with the actual AI camera and, if you can, on
the actual competition floor under its lighting -- HSV values tuned on a
different camera or in different light often need adjusting.

Red wraps around the hue circle (it sits at both ends of 0-180), so a red
goal needs two ranges: tune one end here, then run again for the other
end, and put them in GOAL_HSV_LOW_1/HIGH_1 and GOAL_HSV_LOW_2/HIGH_2.
"""

import argparse
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import config  # noqa: E402

WINDOW = "HSV tuner"
SLIDERS = [("H low", 179), ("S low", 255), ("V low", 255),
           ("H high", 179), ("S high", 255), ("V high", 255)]


def build_mask(frame_bgr, low, high):
    """Same cleanup the tracker applies: threshold, then erode/dilate."""
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, np.array(low), np.array(high))
    mask = cv2.erode(mask, None, iterations=2)
    return cv2.dilate(mask, None, iterations=2)


def _open_live_camera():
    from picamera2 import Picamera2

    picam2 = Picamera2()
    cam_config = picam2.create_preview_configuration(
        main={"size": (config.FRAME_WIDTH, config.FRAME_HEIGHT), "format": "RGB888"}
    )
    picam2.configure(cam_config)
    picam2.start()
    # "RGB888" arrays are already in BGR byte order, which is what OpenCV wants.
    return picam2, (lambda: picam2.capture_array("main")), picam2.stop


def main():
    parser = argparse.ArgumentParser(description="HSV threshold tuner")
    parser.add_argument("--image", help="tune on this image file instead of the live camera")
    args = parser.parse_args()

    if args.image:
        still = cv2.imread(args.image)
        if still is None:
            sys.exit(f"Could not read image: {args.image}")
        grab, stop = (lambda: still.copy()), (lambda: None)
    else:
        _, grab, stop = _open_live_camera()

    cv2.namedWindow(WINDOW)
    start = list(config.TENNIS_BALL_HSV_LOW) + list(config.TENNIS_BALL_HSV_HIGH)
    for (name, maximum), value in zip(SLIDERS, start):
        cv2.createTrackbar(name, WINDOW, int(value), maximum, lambda _v: None)

    print("Sliders start at the ball values from config.py. 'p' prints, 'q' quits.")
    try:
        while True:
            frame = grab()
            vals = [cv2.getTrackbarPos(name, WINDOW) for name, _ in SLIDERS]
            low, high = tuple(vals[:3]), tuple(vals[3:])
            mask = build_mask(frame, low, high)
            cv2.imshow(WINDOW, frame)
            cv2.imshow("mask", mask)

            key = cv2.waitKey(30) & 0xFF
            if key == ord("p"):
                print(f"LOW = {low}\nHIGH = {high}")
            elif key == ord("q"):
                break
    finally:
        stop()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
