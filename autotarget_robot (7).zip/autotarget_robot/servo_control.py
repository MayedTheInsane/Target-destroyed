"""
Servo control via a PCA9685 PWM driver board over I2C.

Requires: adafruit-circuitpython-pca9685 and adafruit-circuitpython-motor
    pip install --break-system-packages adafruit-circuitpython-pca9685 adafruit-circuitpython-motor adafruit-blinka

Wiring reminder (see the mechanical discussion): power the servo from
its OWN 5-6V supply, sharing ground with the Pi/PCA9685 -- do not draw
servo current from the Pi's 5V rail.

The panel servo is the Hitec HS-311 (see config.py for its numbers). It
only turns 120 degrees, not the 180 that adafruit_motor assumes by
default, so every servo here is given an explicit `actuation_range` --
without it a commanded 60 deg would land at the wrong pulse width. If
the servo stalls against the panel it draws far more than when moving
(config.SERVO_STALL_CURRENT_A is a conservative sizing figure), so size
the servo supply for that peak, not its average draw.
"""

import config


class _PCA9685Servo:
    """
    Generic thin wrapper around a single servo channel on a PCA9685,
    exposing set_angle(degrees) clamped to a given [min_deg, max_deg]
    range. PanelServo and CameraPanServo below are just this with their
    own channel/pulse-width/limit numbers plugged in, since a shared
    PCA9685 board can drive several independent servos, one per channel.
    """

    def __init__(
        self,
        channel: int,
        min_pulse_us: int,
        max_pulse_us: int,
        min_deg: float,
        max_deg: float,
        center_deg: float,
        simulate: bool = False,
        label: str = "servo",
        actuation_range: float = 180.0,
    ):
        # actuation_range = how many degrees of travel the servo has between
        # its min and max pulse width (HS-311: 120, most hobby servos: 180).
        # Commanded angles run 0..actuation_range, so every limit below
        # must sit inside that span or the servo would be driven wrong.
        if not (0 <= min_deg <= center_deg <= max_deg <= actuation_range):
            raise ValueError(
                f"{label}: need 0 <= min ({min_deg}) <= center ({center_deg}) <= "
                f"max ({max_deg}) <= actuation_range ({actuation_range}) -- "
                "check the servo settings in config.py."
            )
        self.simulate = simulate
        self._min_deg = min_deg
        self._max_deg = max_deg
        self._center_deg = center_deg
        self._label = label
        self._last_angle = center_deg

        if self.simulate:
            # Lets you develop/test the control logic on a laptop with
            # no hardware attached -- set_angle() just prints and stores.
            return

        import board
        import busio
        from adafruit_pca9685 import PCA9685
        from adafruit_motor import servo

        i2c = busio.I2C(board.SCL, board.SDA)
        pca = PCA9685(i2c)
        pca.frequency = 50  # standard servo PWM frequency

        self._servo = servo.Servo(
            pca.channels[channel],
            actuation_range=actuation_range,
            min_pulse=min_pulse_us,
            max_pulse=max_pulse_us,
        )

    def set_angle(self, degrees: float):
        """Command the servo to an absolute angle, clamped for safety."""
        clamped = max(self._min_deg, min(self._max_deg, degrees))
        self._last_angle = clamped

        if self.simulate:
            print(f"[SIM] {self._label} -> {clamped:.1f} deg")
            return

        self._servo.angle = clamped

    def get_last_angle(self) -> float:
        return self._last_angle

    def center(self):
        self.set_angle(self._center_deg)


class PanelServo(_PCA9685Servo):
    """
    The main reflector-panel yaw servo (the HS-311). Runs throughout
    calibration and the live trial.
    """

    def __init__(self, channel: int = config.PCA9685_CHANNEL, simulate: bool = False):
        super().__init__(
            channel=channel,
            min_pulse_us=config.SERVO_MIN_PULSE_US,
            max_pulse_us=config.SERVO_MAX_PULSE_US,
            min_deg=config.PANEL_MIN_DEG,
            max_deg=config.PANEL_MAX_DEG,
            center_deg=config.SERVO_CENTER_DEG,
            simulate=simulate,
            label="panel servo",
            actuation_range=config.SERVO_MAX_ANGLE_DEG - config.SERVO_MIN_ANGLE_DEG,
        )


class CameraPanServo(_PCA9685Servo):
    """
    Small, cheap servo (e.g. an SG90) on its own PCA9685 channel that
    swivels the camera to actively scan for the goal color during
    calibration only -- see the CAMERA_PAN_* comment block in config.py.
    It is locked at its center angle before the live trial starts and
    is never commanded again during ball tracking.
    """

    def __init__(self, channel: int = config.CAMERA_PAN_CHANNEL, simulate: bool = False):
        super().__init__(
            channel=channel,
            min_pulse_us=config.CAMERA_PAN_MIN_PULSE_US,
            max_pulse_us=config.CAMERA_PAN_MAX_PULSE_US,
            min_deg=config.CAMERA_PAN_MIN_DEG,
            max_deg=config.CAMERA_PAN_MAX_DEG,
            center_deg=config.CAMERA_PAN_CENTER_DEG,
            simulate=simulate,
            label="camera pan servo",
            actuation_range=config.CAMERA_PAN_MAX_DEG - config.CAMERA_PAN_MIN_DEG,
        )


if __name__ == "__main__":
    # Bench test: sweeps the servo across its safe range so you can
    # visually confirm wiring/direction before trusting it in the full
    # control loop. Run with --sim on a laptop with no hardware.
    import sys
    import time

    sim = "--sim" in sys.argv
    panel = PanelServo(simulate=sim)

    print("Sweeping panel angle. Ctrl+C to stop.")
    try:
        while True:
            for angle in range(int(config.PANEL_MIN_DEG), int(config.PANEL_MAX_DEG) + 1, 5):
                panel.set_angle(angle)
                time.sleep(0.05)
            for angle in range(int(config.PANEL_MAX_DEG), int(config.PANEL_MIN_DEG) - 1, -5):
                panel.set_angle(angle)
                time.sleep(0.05)
    except KeyboardInterrupt:
        panel.center()
        print("\nStopped, panel re-centered.")
