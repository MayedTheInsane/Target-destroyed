"""
Interactive HSV threshold tuner.

Run this ON THE ACTUAL COMPETITION FLOOR/LIGHTING if at all possible --
color thresholds that work under one light source often fail under
another. Point the camera at the tennis ball (or the goal patch), drag
the six sliders until only that object shows up white in the mask
window, then copy the printed low/high values into config.py.

Usage:
    python3 tools/hsv_tuner.py

Press 'q' to quit and print the final values.
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import cv2
import config


def nothing(_):
    pass


def main():
    cap = cv2.VideoCapture(config.CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)
    if not cap.isOpened():
        raise RuntimeError("Could not open camera -- check CAMERA_INDEX in config.py")

    window = "HSV tuner (press q to quit)"
    cv2.namedWindow(window)
    cv2.createTrackbar("H low", window, 29, 179, nothing)
    cv2.createTrackbar("H high", window, 64, 179, nothing)
    cv2.createTrackbar("S low", window, 86, 255, nothing)
    cv2.createTrackbar("S high", window, 255, 255, nothing)
    cv2.createTrackbar("V low", window, 6, 255, nothing)
    cv2.createTrackbar("V high", window, 255, 255, nothing)

    print("Adjust sliders until only your target object is white in the mask.")
    print("Press 'q' when done -- final values will be printed for config.py.")

    low = high = None
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                continue

            h_lo = cv2.getTrackbarPos("H low", window)
            h_hi = cv2.getTrackbarPos("H high", window)
            s_lo = cv2.getTrackbarPos("S low", window)
            s_hi = cv2.getTrackbarPos("S high", window)
            v_lo = cv2.getTrackbarPos("V low", window)
            v_hi = cv2.getTrackbarPos("V high", window)

            low = (h_lo, s_lo, v_lo)
            high = (h_hi, s_hi, v_hi)

            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            mask = cv2.inRange(hsv, low, high)
            result = cv2.bitwise_and(frame, frame, mask=mask)

            cv2.imshow(window, frame)
            cv2.imshow("mask", mask)
            cv2.imshow("filtered", result)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()

    if low is not None:
        print("\nFinal HSV range -- paste into config.py:")
        print(f"  LOW  = {low}")
        print(f"  HIGH = {high}")


if __name__ == "__main__":
    main()
