"""
Central configuration for the AutoTarget robot.

Tune the values in this file to match your actual hardware and the
competition floor/lighting, rather than editing constants scattered
through the other modules.
"""

# ----------------------------------------------------------------------
# Camera
# ----------------------------------------------------------------------
CAMERA_INDEX = 0              # /dev/video0 for a USB webcam, or use
                               # picamera2 instead if using the Pi Camera Module
FRAME_WIDTH = 320              # keep resolution modest -> faster loop on a Pi
FRAME_HEIGHT = 240
CAMERA_HFOV_DEG = 62.0         # horizontal field of view of YOUR camera/lens
                               # (check the datasheet -- this number directly
                               # scales every bearing angle you compute)

# HSV color thresholds -- TUNE THESE on the actual competition floor/lighting.
# Use tools/hsv_tuner.py to find good values interactively.
TENNIS_BALL_HSV_LOW = (29, 86, 6)
TENNIS_BALL_HSV_HIGH = (64, 255, 255)

# Set these to the actual goal color assigned/visible for a given run.
# Example values here are for a RED goal -- red wraps around the HSV hue
# circle, so it needs two ranges.
GOAL_HSV_LOW_1 = (0, 120, 70)
GOAL_HSV_HIGH_1 = (10, 255, 255)
GOAL_HSV_LOW_2 = (170, 120, 70)
GOAL_HSV_HIGH_2 = (180, 255, 255)

MIN_BLOB_AREA_PX = 25          # ignore contours smaller than this (noise)

# ----------------------------------------------------------------------
# Servo (panel yaw axis, driven via PCA9685 over I2C)
#
# Set for the DSServo RDS3218, 180deg variant (20kg.cm digital servo,
# metal gear, https://servodatabase.com/servo/dsservo/rds3218):
#   operating voltage: 4.8-6.8V | stall current: 1.6-2.5A
#   pulse width: 500-2500us    | speed: ~0.17-0.20 sec/60deg
#
# SERVO_CENTER_DEG below is set to 90.0 (the midpoint of 0-180) as a
# starting default -- confirm this against your actual mechanical
# zero-point once the panel is mounted on the horn, since the true
# center depends on how the horn happens to sit when you bolt it on,
# not just the math midpoint.
# ----------------------------------------------------------------------
PCA9685_CHANNEL = 0
SERVO_MIN_PULSE_US = 500       # RDS3218 datasheet: 500-2500us
SERVO_MAX_PULSE_US = 2500
SERVO_MIN_ANGLE_DEG = 0.0
SERVO_MAX_ANGLE_DEG = 180.0
SERVO_CENTER_DEG = 90.0        # panel angle that corresponds to panel-normal=0 (forward);
                               # confirm/adjust from your mechanical zero-point

# Panel angle safety clamp -- keep some margin off the mechanical end-stops
PANEL_MIN_DEG = 10.0
PANEL_MAX_DEG = 170.0

# RDS3218 electrical characteristics, used only as documentation/reference
# for sizing the power supply in servo_control.py's docstring and your BOM --
# not read by any code path.
SERVO_STALL_CURRENT_A = 2.5     # worst-case stall draw per servo (amps)
SERVO_OPERATING_VOLTAGE_V = (4.8, 6.8)  # min/max safe supply voltage

# ----------------------------------------------------------------------
# Camera pan servo -- CALIBRATION-ONLY. A small, cheap servo (e.g. an
# SG90) on its own PCA9685 channel that swivels the camera to actively
# scan for the goal color during the up-to-5-minute calibration window,
# instead of passively waiting for the goal to sit inside a fixed field
# of view. It is locked back to CAMERA_PAN_CENTER_DEG before the live
# trial starts and is never touched again during ball tracking, so it
# adds no latency/complexity to the real-time reaction loop.
# ----------------------------------------------------------------------
CAMERA_PAN_CHANNEL = 1
CAMERA_PAN_MIN_PULSE_US = 500      # adjust to your actual pan servo's datasheet
CAMERA_PAN_MAX_PULSE_US = 2400
CAMERA_PAN_MIN_DEG = 0.0
CAMERA_PAN_MAX_DEG = 180.0
CAMERA_PAN_CENTER_DEG = 90.0       # pan angle at which the camera points straight
                                   # along the robot's forward axis (0 deg bearing);
                                   # confirm against your actual mechanical mount

# ----------------------------------------------------------------------
# Control loop
# ----------------------------------------------------------------------
CALIBRATION_SCAN_STEP_DEG = 10   # how far to pan/step while searching for goal
CALIBRATION_SCAN_SETTLE_S = 0.15  # pause after each pan step for the servo to
                                   # stop moving and the frame to be fresh
LIVE_LOOP_HZ = 15                 # camera+control loop rate during a trial
BEARING_SMOOTHING_ALPHA = 0.5     # exponential smoothing factor (0=no update, 1=no smoothing)
