# AutoTarget robot control code

Code sketch for the ball-redirection robot: camera-based bearing tracking
+ reflection-angle math + servo panel control.

## Files

- `config.py` -- all tunable constants (camera FOV, HSV color thresholds,
  servo pins/limits, loop rate). Start here.
- `reflection.py` -- pure geometry, no hardware. Turns (incoming ball
  bearing, goal bearing) into the panel angle that reflects one into the
  other. Run `python3 reflection.py` to sanity-check the math.
- `camera_tracker.py` -- OpenCV color-blob tracking. Finds the ball and
  the goal patch in a frame and converts pixel position to a bearing
  angle. Run directly for a live preview with bearings printed to console.
- `servo_control.py` -- PCA9685-based servo driver wrapper. Defines
  `PanelServo` (the main reflector servo) and `CameraPanServo` (a second,
  small servo -- e.g. an SG90 -- that swivels the camera during
  calibration only, on its own PCA9685 channel). Run with `--sim` to
  test without hardware, or without it to sweep a real servo.
- `main.py` -- ties it together: calibration phase (actively pan the
  camera to find the goal bearing) then a live loop (track the ball,
  update the panel angle in real time). The camera pan servo only moves
  during calibration -- it's locked to a fixed angle before the live
  loop starts and is never touched again.
- `tools/hsv_tuner.py` -- interactive slider tool to find good HSV
  thresholds for the tennis ball and goal color, using your actual
  camera and lighting. Run this FIRST, on the real competition floor if
  you can, before trusting `config.py`'s default values.

## Setup on the Raspberry Pi

```bash
pip install --break-system-packages opencv-python \
    adafruit-circuitpython-pca9685 adafruit-circuitpython-motor adafruit-blinka
```

Enable I2C via `raspi-config` if you haven't already (needed for the
PCA9685 servo driver board).

## Suggested order of testing

1. `python3 reflection.py` -- confirms the trig is right (no hardware needed).
2. `python3 servo_control.py --sim` then without `--sim` on the Pi --
   confirms wiring/direction of the real servo before anything else
   depends on it.
3. `python3 tools/hsv_tuner.py` -- dial in HSV thresholds for the ball
   and for the goal color, update `config.py` with the values it prints.
4. `python3 camera_tracker.py` -- confirms both the ball and goal are
   detected reliably and bearings look sane as you move them around.
5. `python3 main.py` -- full calibration + live loop. Use `--sim` if you
   want to test the flow/timing without moving the real servo yet.

## Known gaps to fill in before competition

- `config.py`'s `CAMERA_HFOV_DEG`, `SERVO_CENTER_DEG`, and
  `CAMERA_PAN_CENTER_DEG` are placeholders -- measure/calibrate these
  against your actual camera and mechanical zero-points.
- The goal color (`GOAL_HSV_LOW/HIGH`) is set for red as an example;
  update for whichever color you're assigned/using.
- `CAMERA_PAN_CHANNEL` assumes the pan servo is on a second, separate
  PCA9685 channel (channel 1, alongside the panel servo's channel 0) on
  the *same* board -- if you wire it to a second board or a different
  channel, update that constant. Also size a small 5V supply for the
  pan servo (an SG90 draws far less than the RDS3218, but still don't
  pull it from the Pi's own 5V rail if you can avoid it).
- No obstacle/edge-case handling yet for the ball briefly leaving the
  frame mid-approach -- currently it just holds the last angle, which is
  a reasonable default but worth testing against real ball speeds.
- `main.py` now transitions from calibration straight into the live
  trial with no manual prompt, per the competition's no-intervention
  rule -- double check the calibration scan reliably finds the goal
  before relying on that in a real run.
