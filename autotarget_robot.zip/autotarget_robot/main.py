"""
Top-level control script for the AutoTarget robot.

Two phases, matching the competition structure:

  1. CALIBRATION (up to 5 minutes): scan to find the goal's bearing,
     lock it in, and center the panel at a sensible starting angle.

  2. LIVE TRIAL: continuously track the incoming ball's bearing with the
     camera and update the panel angle in real time using the reflection
     formula, so the ball gets redirected toward the (now-known) goal
     bearing no matter which direction it happens to arrive from.

Run with `python3 main.py --sim` to exercise the whole flow on a laptop
with no camera/servo hardware attached (uses a fake camera feed and
prints servo commands instead of moving a real motor) -- useful for
testing the control logic and timing before deploying to the Pi.
"""

import argparse
import time

import config
import camera_tracker
import reflection
from servo_control import PanelServo, CameraPanServo


def calibrate(cap, panel: PanelServo, cam_pan: CameraPanServo) -> float:
    """
    Actively scan with the camera-pan servo to find the goal-colored
    patch, and return its bearing (degrees, relative to the robot's
    forward axis -- i.e. the axis the panel/servo geometry is calibrated
    against, NOT the camera's own centerline, since the camera is now
    swiveling independently of the panel during this phase only).

    Strategy: step the pan servo from CAMERA_PAN_MIN_DEG to
    CAMERA_PAN_MAX_DEG (and back, repeating) in CALIBRATION_SCAN_STEP_DEG
    increments, sampling a frame after each move. As soon as the goal is
    seen, the true bearing is the pixel-based in-frame bearing PLUS the
    pan servo's current offset from its center (CAMERA_PAN_CENTER_DEG),
    since that offset is how far the camera itself is turned away from
    the robot's forward axis. The pan servo is then re-centered and left
    alone -- this function is the only place it ever moves.
    """
    print("Calibration: sweeping camera to search for goal color...")
    deadline = time.time() + 5 * 60  # 5-minute calibration window

    pan_angle = config.CAMERA_PAN_MIN_DEG
    step = config.CALIBRATION_SCAN_STEP_DEG
    cam_pan.set_angle(pan_angle)

    try:
        while time.time() < deadline:
            cam_pan.set_angle(pan_angle)
            time.sleep(config.CALIBRATION_SCAN_SETTLE_S)

            frame, outputs = camera_tracker.read_frame(cap)
            if frame is not None:
                pixel_bearing = camera_tracker.get_goal_bearing(frame, outputs)
                if pixel_bearing is not None:
                    pan_offset = cam_pan.get_last_angle() - config.CAMERA_PAN_CENTER_DEG
                    goal_bearing = pixel_bearing + pan_offset
                    print(
                        f"Goal found at pan={pan_angle:.1f} deg "
                        f"(pixel bearing {pixel_bearing:+.1f} deg) "
                        f"-> robot-relative goal bearing {goal_bearing:+.1f} deg."
                    )
                    return goal_bearing

            # Step to the next pan angle, bouncing back and forth between
            # the servo's limits rather than snapping back to MIN each time.
            pan_angle += step
            if pan_angle > config.CAMERA_PAN_MAX_DEG:
                step = -step
                pan_angle = config.CAMERA_PAN_MAX_DEG + step
            elif pan_angle < config.CAMERA_PAN_MIN_DEG:
                step = -step
                pan_angle = config.CAMERA_PAN_MIN_DEG + step

        raise RuntimeError(
            "Calibration timed out without finding the goal. Check "
            "GOAL_HSV_LOW/HIGH in config.py against the actual goal color, "
            "or verify the goal patch can be seen from some pan angle within "
            "CAMERA_PAN_MIN_DEG/CAMERA_PAN_MAX_DEG."
        )
    finally:
        # Calibration-only swivel: lock the camera back to its fixed,
        # known orientation before the live trial ever starts.
        cam_pan.center()


def run_live_trial(cap, panel: PanelServo, goal_bearing_deg: float):
    """
    Main real-time loop: track the ball, compute the panel angle via
    the reflection formula, and command the servo -- repeatedly, so the
    panel keeps adjusting as the ball's apparent bearing changes while
    it approaches.
    """
    print(f"Live trial started. Goal bearing locked at {goal_bearing_deg:+.1f} deg.")
    period = 1.0 / config.LIVE_LOOP_HZ
    smoothed_bearing = None

    try:
        while True:
            loop_start = time.time()

            frame, outputs = camera_tracker.read_frame(cap)
            if frame is not None:
                ball_bearing = camera_tracker.get_ball_bearing(frame, outputs)

                if ball_bearing is not None:
                    if smoothed_bearing is None:
                        smoothed_bearing = ball_bearing
                    else:
                        a = config.BEARING_SMOOTHING_ALPHA
                        smoothed_bearing = a * ball_bearing + (1 - a) * smoothed_bearing

                    panel_normal = reflection.panel_angle_from_bearings(
                        smoothed_bearing, goal_bearing_deg
                    )
                    servo_angle = reflection.servo_angle_from_panel_normal(
                        panel_normal, config.SERVO_CENTER_DEG
                    )
                    panel.set_angle(servo_angle)

                    print(
                        f"ball={smoothed_bearing:+6.1f} deg  "
                        f"panel_normal={panel_normal:+6.1f} deg  "
                        f"servo={panel.get_last_angle():6.1f} deg",
                        end="\r",
                    )
                # If the ball isn't currently visible, hold the last
                # commanded angle rather than snapping back to center --
                # avoids jittering the panel every time the ball briefly
                # drops out of the color threshold.

            elapsed = time.time() - loop_start
            time.sleep(max(0.0, period - elapsed))

    except KeyboardInterrupt:
        print("\nLive trial stopped by user.")


def main():
    parser = argparse.ArgumentParser(description="AutoTarget robot control")
    parser.add_argument(
        "--sim", action="store_true",
        help="Run without real hardware: prints servo commands, still needs a camera "
             "(or webcam) for the vision pipeline unless you also stub that out."
    )
    args = parser.parse_args()

    cap = camera_tracker.open_capture()
    panel = PanelServo(simulate=args.sim)
    cam_pan = CameraPanServo(simulate=args.sim)
    panel.center()
    cam_pan.center()

    try:
        goal_bearing_deg = calibrate(cap, panel, cam_pan)
        # cam_pan is already re-centered and locked by calibrate() -- it is
        # not touched again below; run_live_trial() only ever moves `panel`.
        run_live_trial(cap, panel, goal_bearing_deg)
    finally:
        cap.stop()
        panel.center()
        cam_pan.center()


if __name__ == "__main__":
    main()
