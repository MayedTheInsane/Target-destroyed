# AutoTarget robot control code

Code sketch for the ball-redirection robot: camera-based bearing tracking
+ reflection-angle math + servo panel control.

## Files

- `config.py` -- all tunable constants (camera FOV, IMX500 model path/
  class indices, servo pins/limits, loop rate). Start here.
- `reflection.py` -- pure geometry, no hardware. Turns (incoming ball
  bearing, goal bearing) into the panel angle that reflects one into the
  other. Run `python3 reflection.py` to sanity-check the math.
- `camera_tracker.py` -- Raspberry Pi AI Camera (IMX500) on-sensor
  neural-network detection. Loads a custom-trained model onto the
  camera sensor and reads back bounding-box detections for the ball
  and the goal patch, converting each to a bearing angle. Run directly
  for a live preview with bearings printed to console. Requires a
  trained-and-converted model already deployed on the Pi -- see
  "Training and deploying the detection model" below.
- `servo_control.py` -- PCA9685-based servo driver wrapper. Defines
  `PanelServo` (the main reflector servo) and `CameraPanServo` (a second,
  small servo -- e.g. an SG90 -- that swivels the camera during
  calibration only, on its own PCA9685 channel). Run with `--sim` to
  test without hardware, or without it to sweep a real servo.
- `main.py` -- ties it together: calibration phase (actively pan the
  camera to find the goal bearing) then a live loop (track the ball,
  update the panel angle in real time). The camera pan servo only moves
  during calibration -- it's locked to a fixed angle before the live
  loop starts and is never touched again.
- `tools/hsv_tuner.py` -- LEGACY. Interactive slider tool for the old
  OpenCV color-threshold approach. Not part of the current IMX500 NN
  pipeline; kept only as a fallback path (see config.py's "legacy"
  section) in case the trained model isn't ready in time.

## Training and deploying the detection model

Unlike the old HSV approach, the ball and goal patch are now found by a
model that has to be trained *before* you can run anything on the
robot. Roughly, in order:

1. **Collect images.** Photograph the tennis ball and the goal patch
   from the camera's actual mounted viewpoint, under lighting as close
   to the competition venue as you can get. Get variety: different
   distances, angles, and a good number of "background only" frames
   with neither object present.
2. **Label them.** Draw bounding boxes around the ball and the goal
   patch in each image with a labeling tool (e.g. CVAT, LabelImg,
   Roboflow). Keep the class order consistent -- whatever order you
   assign here is what `IMX500_BALL_CLASS_INDEX` / `IMX500_GOAL_CLASS_INDEX`
   in `config.py` must match.
3. **Train a detector.** Use a lightweight architecture supported by
   the IMX500 toolchain (NanoDet is what `camera_tracker.py` assumes --
   see its module docstring). Sony/Raspberry Pi publish transfer-learning
   recipes for this rather than training from scratch.
4. **Convert for the IMX500.** Run the trained model through Sony's
   IMX500 conversion toolchain to produce a `.rpk` network package --
   this is the on-sensor-deployable format, not the raw training
   checkpoint.
5. **Deploy.** Copy the `.rpk` file onto the Pi and point
   `config.IMX500_MODEL_PATH` at it.
6. **Verify class indices.** Set `IMX500_BALL_CLASS_INDEX` and
   `IMX500_GOAL_CLASS_INDEX` in `config.py` to match the label order
   from step 2 -- these are arbitrary to your training data, not a
   fixed standard.

None of this happens automatically -- steps 1-4 are offline work you do
ahead of the competition, well before any of the Python files here get
run.

## Setup on the Raspberry Pi

```bash
pip install --break-system-packages picamera2 \
    adafruit-circuitpython-pca9685 adafruit-circuitpython-motor adafruit-blinka
```

Enable I2C via `raspi-config` if you haven't already (needed for the
PCA9685 servo driver board), and enable the IMX500 camera overlay per
the Raspberry Pi AI Camera setup guide.

## Suggested order of testing

1. `python3 reflection.py` -- confirms the trig is right (no hardware needed).
2. `python3 servo_control.py --sim` then without `--sim` on the Pi --
   confirms wiring/direction of the real servo before anything else
   depends on it.
3. Train and deploy the detection model (see above) -- nothing camera-
   related works without this in place first.
4. `python3 camera_tracker.py` -- confirms both the ball and goal are
   detected reliably and bearings look sane as you move them around.
   If detections look wrong or missing, start by checking
   `IMX500_MIN_CONFIDENCE` and the class-index mapping in `config.py`.
5. `python3 main.py` -- full calibration + live loop. Use `--sim` if you
   want to test the servo-command flow/timing without moving the real
   panel servo yet (the camera/model still need to be real either way).

## Known gaps to fill in before competition

- `config.py`'s `CAMERA_HFOV_DEG`, `SERVO_CENTER_DEG`, and
  `CAMERA_PAN_CENTER_DEG` are placeholders -- measure/calibrate these
  against your actual camera and mechanical zero-points.
- `IMX500_MODEL_PATH`, `IMX500_BALL_CLASS_INDEX`, and
  `IMX500_GOAL_CLASS_INDEX` are all placeholders until you've actually
  trained, converted, and deployed a model -- see "Training and
  deploying the detection model" above.
- `IMX500_MIN_CONFIDENCE` hasn't been tuned against a real trained
  model yet -- start conservative and adjust once you can see real
  detection scores.
- `camera_tracker.py`'s output-parsing assumes a NanoDet-style model
  (matching picamera2's own IMX500 examples) -- if your training/
  conversion pipeline produces a different architecture, the box/score/
  class unpacking in `_best_detection_for_class()` will need adjusting
  to match. Check against picamera2's example scripts on your Pi.
- `CAMERA_PAN_CHANNEL` assumes the pan servo is on a second, separate
  PCA9685 channel (channel 1, alongside the panel servo's channel 0) on
  the *same* board -- if you wire it to a second board or a different
  channel, update that constant. Also size a small 5V supply for the
  pan servo (an SG90 draws far less than the RDS3218, but still don't
  pull it from the Pi's own 5V rail if you can avoid it).
- No obstacle/edge-case handling yet for the ball briefly leaving the
  frame mid-approach -- currently it just holds the last angle, which is
  a reasonable default but worth testing against real ball speeds.
- `main.py` now transitions from calibration straight into the live
  trial with no manual prompt, per the competition's no-intervention
  rule -- double check the calibration scan reliably finds the goal
  before relying on that in a real run.
