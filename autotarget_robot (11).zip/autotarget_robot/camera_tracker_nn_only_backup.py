"""
Raspberry Pi AI Camera (IMX500) on-sensor neural-network tracking.

Both the tennis ball and the goal patch are found by a CUSTOM-TRAINED
detection model running directly on the camera sensor -- not OpenCV
color thresholding. This only works because the goal color/appearance
is known well ahead of the competition, giving time to collect images
and train/convert a model before the event.

Requires:
    pip install --break-system-packages picamera2

Also requires (see README.md for the full pipeline):
    - The IMX500 device-tree overlay enabled on the Pi (Raspberry Pi AI
      Camera setup guide -- dtoverlay in /boot/firmware/config.txt).
    - A trained-and-converted model package (.rpk file) already
      deployed to the Pi, with its path set in config.IMX500_MODEL_PATH.
      Training/converting that model happens OFFLINE, ahead of time --
      nothing in this file trains anything at runtime, it only loads
      and runs an already-trained model.

IMPORTANT: the exact shape of `outputs` from imx500.get_outputs() and
which postprocessing helper (postprocess_nanodet_detection or another)
applies depends on the architecture your training/conversion pipeline
actually produces. This file assumes a NanoDet-style single-class-per-box
detector, matching the picamera2 IMX500 example scripts as of early
2026 -- check those example scripts on your Pi (wherever picamera2 is
installed, typically under its examples/imx500/ directory) against
whatever your conversion toolchain output, and adjust
`_best_detection_for_class()` if the shapes don't match. This is the one
part of the pipeline that depends on your specific trained model and
can't be fully pinned down without it in hand.
"""

from picamera2 import Picamera2
from picamera2.devices import IMX500
from picamera2.devices.imx500 import postprocess_nanodet_detection

import config


_imx500 = None
_picam2 = None


def open_capture():
    """
    Load the trained model onto the IMX500 sensor and start the camera.
    Returns the Picamera2 instance; read_frame() pulls both the frame
    and the on-sensor detection results from it.
    """
    global _imx500, _picam2

    _imx500 = IMX500(config.IMX500_MODEL_PATH)
    _picam2 = Picamera2(_imx500.camera_num)

    cam_config = _picam2.create_preview_configuration(
        main={"size": (config.FRAME_WIDTH, config.FRAME_HEIGHT)},
        controls={"FrameRate": config.LIVE_LOOP_HZ},
        buffer_count=4,
    )
    _picam2.configure(cam_config)
    _picam2.start()

    return _picam2


def read_frame(cap):
    """
    Grab one frame (numpy array, only needed for its width/height and
    any debug preview) plus the raw on-sensor NN outputs for that same
    frame.

    Returns (frame, outputs). `outputs` is None if no detection metadata
    was ready yet for this particular frame (normal for the first few
    frames after start()) -- callers should treat that the same as "no
    detections this frame," not an error.
    """
    request = cap.capture_request()
    try:
        frame = request.make_array("main")
        metadata = request.get_metadata()
        outputs = _imx500.get_outputs(metadata, add_batch=True)
    finally:
        request.release()

    return frame, outputs


def _best_detection_for_class(outputs, frame_shape, class_index, min_confidence):
    """
    From one frame's raw NN outputs, pick the highest-confidence
    detection matching `class_index` and return its box center as
    (cx, cy) in pixel coordinates, or None if nothing qualifies.
    """
    if outputs is None:
        return None

    boxes, scores, classes = postprocess_nanodet_detection(
        outputs=outputs,
        conf=min_confidence,
        iou_thres=0.5,
        max_out_dets=10,
    )[0]

    best = None
    best_score = min_confidence
    height, width = frame_shape[:2]

    for box, score, cls in zip(boxes, scores, classes):
        if int(cls) != class_index or score < best_score:
            continue
        # box is normalized [x0, y0, x1, y1] -- convert to pixel center
        x0, y0, x1, y1 = box
        cx = ((x0 + x1) / 2.0) * width
        cy = ((y0 + y1) / 2.0) * height
        best = (cx, cy)
        best_score = score

    return best


def pixel_offset_to_bearing(cx: float, frame_width: int, hfov_deg: float) -> float:
    """
    Convert a detection's horizontal pixel center `cx` into a bearing
    angle relative to the camera's centerline, in degrees. Unchanged
    from the color-threshold version -- same pinhole-linear
    approximation, same convention (0 = centerline, + = right, - = left).
    """
    frame_center = frame_width / 2.0
    pixel_offset = cx - frame_center
    fraction_of_half_fov = pixel_offset / frame_center
    return fraction_of_half_fov * (hfov_deg / 2.0)


def get_ball_bearing(frame, outputs):
    """Returns ball bearing in degrees, or None if not detected this frame."""
    center = _best_detection_for_class(
        outputs, frame.shape, config.IMX500_BALL_CLASS_INDEX, config.IMX500_MIN_CONFIDENCE
    )
    if center is None:
        return None
    cx, _ = center
    return pixel_offset_to_bearing(cx, frame.shape[1], config.CAMERA_HFOV_DEG)


def get_goal_bearing(frame, outputs):
    """Returns goal-patch bearing in degrees, or None if not detected this frame."""
    center = _best_detection_for_class(
        outputs, frame.shape, config.IMX500_GOAL_CLASS_INDEX, config.IMX500_MIN_CONFIDENCE
    )
    if center is None:
        return None
    cx, _ = center
    return pixel_offset_to_bearing(cx, frame.shape[1], config.CAMERA_HFOV_DEG)


if __name__ == "__main__":
    # Quick manual test: run this on the Pi to see live ball/goal
    # detection and bearing numbers printed to the console.
    cap = open_capture()
    print("Press Ctrl+C to quit.")
    try:
        while True:
            frame, outputs = read_frame(cap)
            ball_bearing = get_ball_bearing(frame, outputs)
            goal_bearing = get_goal_bearing(frame, outputs)

            ball_txt = f"{ball_bearing:+.1f} deg" if ball_bearing is not None else "not found"
            goal_txt = f"{goal_bearing:+.1f} deg" if goal_bearing is not None else "not found"
            print(f"ball: {ball_txt:>14} | goal: {goal_txt:>14}", end="\r")
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        cap.stop()
