# AutoTarget robot control code

Code sketch for the ball-redirection robot: camera-based bearing tracking
+ reflection-angle math + servo panel control.

## How it works

- **Ball** -- found by the Raspberry Pi AI Camera's on-sensor neural
  network, using the **"sports ball"** class of the stock COCO
  object-detection model that ships with the camera.
- **Goal patch** -- found by OpenCV **HSV color thresholding** on the
  same camera frame.
- **Panel** -- an HS-311 servo wired straight to a Pi GPIO pin turns the
  panel so that its normal bisects the ball and goal bearings (law of
  reflection), updated every frame.

## Files

- `config.py` -- all tunable constants (camera FOV, NN model/ball label,
  HSV thresholds, detection mode, servo pins/limits, loop rate). Start here.
- `reflection.py` -- pure geometry, no hardware. Turns (incoming ball
  bearing, goal bearing) into the panel angle that reflects one into the
  other. Run `python3 reflection.py` to sanity-check the math.
- `camera_tracker.py` -- runs the NN and HSV detectors on each frame and
  converts the chosen position to a bearing angle (0 = camera centerline,
  + = right). Run `python3 camera_tracker.py` to see what each detector
  sees: it opens a preview window automatically when a screen is
  available (`--preview` forces it, `--no-preview` turns it off).
- `camera_tracker_hsv_only_backup.py`, `camera_tracker_nn_only_backup.py`
  -- the previous single-detector versions, kept for rollback only.
  Nothing imports them.
- `servo_control.py` -- drives servos directly from GPIO pins with
  gpiozero (through the pigpio daemon for steady pulses). Defines
  `PanelServo` (the HS-311 reflector). Run `python3 servo_control.py` to sweep the panel
  servo on the bench, or add `--sim` to test without hardware.
- `main.py` -- ties it together: calibration phase (the camera is fixed,
  so it just watches for the goal and locks in the median of 20 sightings),
  then a live loop (track the ball, update the panel angle in real time).
- `tools/hsv_tuner.py` -- interactive slider tool for finding the HSV
  thresholds for the goal color (and ball, if you ever use it), reading
  frames from the AI camera (or `--image photo.jpg`). Re-tune with the AI
  camera itself -- thresholds found with a USB webcam won't carry over.

## Detection modes

`config.DETECTION_MODE_BALL` and `DETECTION_MODE_GOAL` choose, per
target, how the two detectors are used. Shipped setting: ball
`"nn_only"`, goal `"hsv_only"`.

| mode | behavior |
|---|---|
| `"nn_only"` | Neural network only. Refuses to start if the model can't be loaded. |
| `"hsv_only"` | Color threshold only; needs no model file. |
| `"fused"` | Both. If they agree (horizontal centers within `FUSION_AGREE_TOL_FRAC` of the frame width) the result is a weighted average (`FUSION_NN_WEIGHT`); if only one sees the target, that one is used; if both see it but disagree, `FUSION_PRIMARY` wins. If the model can't load or its output can't be parsed, it degrades to HSV-only with a printed warning. |

If the stock model turns out to miss the ball too often (see "Known
gaps"), the cheapest fallback is `DETECTION_MODE_BALL = "fused"` with the
ball's HSV range tuned in `tools/hsv_tuner.py`: HSV then covers frames
where the NN sees nothing. A custom-trained model with its own ball and
goal classes is also possible later -- point `IMX500_MODEL_PATH` at the
converted `.rpk` and set `IMX500_BALL_CLASS_INDEX` /
`IMX500_GOAL_CLASS_INDEX`.

### How the ball's class is found

The stock model's class numbers differ between COCO numbering schemes,
so `camera_tracker.py` doesn't hard-code one. At start-up it looks up
`IMX500_BALL_LABEL` (`"sports ball"`) in the model's own label list, or
in a built-in COCO list if the model carries none, and prints what it
chose, e.g. `Ball = 'sports ball' -> NN class 32 (from ...)`. Set
`IMX500_BALL_CLASS_INDEX` to override it.

## Setup on the Raspberry Pi

```bash
sudo apt install -y imx500-all libopenblas0 python3-gpiozero pigpio python3-pigpio
sudo systemctl enable --now pigpiod        # steady servo pulses; starts on every boot
pip install --break-system-packages opencv-python numpy
```

(`picamera2` ships with Raspberry Pi OS; install it with apt if missing.)
Enable the IMX500 camera per the Raspberry Pi AI Camera setup guide.
`imx500-all` installs the stock models under `/usr/share/imx500-models/`,
including the one `config.IMX500_MODEL_PATH` points at. No I2C setup is
needed any more -- the PCA9685 board is gone.

### Wiring (BCM pin numbers, set in `config.py`)

| servo | signal pin | power |
|---|---|---|
| HS-311 panel | GPIO17 (physical pin 11) -- `PANEL_GPIO_PIN` | its OWN 4.8-6 V supply |

Servo power must NOT come from the Pi's 5 V pin (a stalled servo can
brown out the Pi). Join the servo supply's ground to a Pi ground pin, or
the signal has no reference and the servo will jitter or ignore it. The
Pi's 3.3 V signal level is fine for these servos.

## Suggested order of testing

1. `python3 reflection.py` -- confirms the trig is right (no hardware needed).
2. `python3 servo_control.py` on the Pi -- sweeps the panel servo so you
   can confirm wiring, direction, and that it isn't buzzing. If it
   prints a pigpio warning, run `sudo systemctl enable --now pigpiod`.
3. `python3 tools/hsv_tuner.py` -- tune the goal color's HSV range on
   the AI camera and copy the printed values into `config.py`.
4. `python3 camera_tracker.py` -- hold a tennis ball in view.
   The NN column should show a detection labelled `sports ball` (or the
   class number the start-up line printed) and the preview window draws
   its box; the goal patch should show up in the HSV column.
5. `python3 main.py` -- full calibration + live loop (the goal must be in the fixed camera's view). Use `--sim` to test
   the servo-command flow without moving the real servos (the camera
   and model still need to be real either way).

## Angle offsets (camera vs. panel)

The reflection maths needs every bearing in the **robot's** frame, where 0 is
the direction the panel normal faces at `SERVO_CENTER_DEG`. Two settings tie
the camera and servo to that frame:

- `CAMERA_YAW_OFFSET_DEG` -- how far the camera is turned from robot-forward
  (positive = camera points right). Added to the ball and goal bearings.
  Measure it with `python3 tools/measure_camera_offset.py` (instructions in
  the file): put the ball exactly along the panel normal and it prints the
  value to use.
- `PANEL_DIRECTION` -- `+1` if a larger servo angle turns the panel normal to
  the right, `-1` if to the left. Flip it if the panel swings the wrong way.

Also check `SERVO_CENTER_DEG` (the servo angle where the panel normal really
points forward) and `CAMERA_HFOV_DEG`. The camera and panel pivot are not at
the same spot, which adds a small parallax error for close balls; mount the
camera as close above the pivot as you can.

## No preview window?

`camera_tracker.py` and `tools/hsv_tuner.py` draw their windows with
OpenCV, which needs a desktop. The tracker prints a `Preview:` line at
start-up saying what it chose.

- Run from a terminal (or Geany's Run) **inside the Pi's desktop** --
  the VNC session or a monitor -- not a plain SSH shell. Geany's Run
  button passes no arguments, which is fine now: the window is on by
  default when a screen is found.
- If it says `snapshots only`, no screen was found (`DISPLAY` /
  `WAYLAND_DISPLAY` unset). Either run it on the desktop, or open
  `camera_preview.jpg` (saved next to the script, refreshed about once a
  second) from the file manager.
- If it prints `Could not open a preview window (...)`, OpenCV's GUI
  backend is broken (typically a Qt `xcb` / `wayland` plugin error).
  Try `sudo apt install python3-opencv` and
  `pip uninstall opencv-python`, then rerun. Snapshots keep working
  meanwhile.
- `QT_QPA_PLATFORM=xcb python3 camera_tracker.py` sometimes helps on
  Wayland desktops.

## Known gaps to fill in before competition

- **Stock model vs. a tennis ball (the biggest risk).** The ball is
  found only by a generic COCO model, which was not trained for a small,
  fast tennis ball. It may miss it at distance or when it's blurred.
  Check how reliably step 4 above detects a rolling ball at the real
  distances; if it's poor, lower `IMX500_MIN_CONFIDENCE`, or move to
  `"fused"` (above), or train a custom model.
- **Never run against real hardware.** The detection, label lookup,
  fusion, servo driver and main loop have been tested off the Pi using
  stand-ins for picamera2, the IMX500 and gpiozero -- not the real
  libraries or devices. `_parse_nn_detections()` follows picamera2's
  `imx500_object_detection_demo.py`. If boxes land in the wrong place or
  labels look shifted, try the `IMX500_BBOX_*` / `IMX500_IGNORE_DASH_LABELS`
  overrides in `config.py`, and compare with that demo script on your Pi.
  If the NN output can't be parsed, the NN is switched off for the run
  with a warning -- and with the ball set to `"nn_only"` the robot then
  sees no ball, so watch the console.
- `config.py`'s `CAMERA_HFOV_DEG` and `SERVO_CENTER_DEG` are placeholders -- measure/calibrate these
  against your actual camera and mechanical zero-points.
- **Fixed camera, goal must be in view.** There is no pan servo and no
  sweep: calibration only sees a goal inside the camera's field of view
  (about +-33 degrees). Aim the camera so the goal patch is visible, or
  calibration times out after 5 minutes with an error. Since the goal is
  placed randomly, check the camera's view covers where it can go, or
  widen `CAMERA_HFOV_DEG` coverage with a wider lens.
- **HS-311 limits.** 120 degrees of travel, 575-2460 us, about
  3.0-3.7 kg.cm of torque. `servo_control.py` passes the 120 degree range
  to gpiozero; a 180 degree assumption would put every angle at the wrong
  pulse. On the bench, check that the panel sits facing forward at
  `SERVO_CENTER_DEG = 60`, that it moves the right direction (flip the
  sign if not), and that the panel and bracket are light enough for the
  torque. The stall-current figure in `config.py` is an estimate, not a
  datasheet value.
- **Reach.** With the 5 degree end-stop margins the panel normal can
  turn +-55 degrees. Since the normal is (ball + goal) / 2 and the camera
  sees ball bearings out to +-33 degrees, any goal within about +-77
  degrees of forward is fully covered. Goals further round (up to +-110)
  are only served for some ball directions, and beyond that the command
  is clamped at the end-stop, so the ball won't be sent accurately at
  the goal. If the goal can sit further round than that, the panel's
  mounting angle has to change (or a servo with more travel be used).
- The fusion settings (`FUSION_*`) only matter in `"fused"` mode and are
  untuned defaults.
- No obstacle/edge-case handling yet for the ball briefly leaving the
  frame mid-approach -- currently it just holds the last angle, which is
  a reasonable default but worth testing against real ball speeds.
- `main.py` transitions from calibration straight into the live trial
  with no manual prompt, per the competition's no-intervention rule --
  double check calibration reliably finds the goal before
  relying on that in a real run.
