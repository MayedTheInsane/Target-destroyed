"""
OpenCV color-blob tracking: finds the tennis ball and/or the goal patch
in a camera frame and converts their pixel position into a bearing angle
relative to the robot (0 deg = camera centerline, + = right, - = left).

Requires: opencv-python (pip install opencv-python) and a camera the
Pi can see via /dev/video0 (or picamera2, if using the Pi Camera Module
-- see the note in `open_capture()` below).
"""

import math
import cv2
import numpy as np

import config


def open_capture():
    """
    Open the camera. For a USB webcam this is plain OpenCV VideoCapture.

    If you're using the Raspberry Pi Camera Module (not a USB webcam),
    OpenCV's VideoCapture often can't see it directly on newer Pi OS
    releases -- use picamera2 to grab frames instead and adapt
    `read_frame()` accordingly. That swap is isolated to these two
    functions; nothing else in this file needs to change.
    """
    cap = cv2.VideoCapture(config.CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, config.FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, config.FRAME_HEIGHT)
    if not cap.isOpened():
        raise RuntimeError(
            "Could not open camera at index "
            f"{config.CAMERA_INDEX}. Check the USB connection / "
            "camera index, or see the picamera2 note in open_capture()."
        )
    return cap


def read_frame(cap):
    ok, frame = cap.read()
    if not ok:
        return None
    return frame


def _largest_blob_centroid(mask):
    """
    Given a binary mask, return (cx, cy, area) of the largest contour,
    or None if nothing found above the minimum-area noise threshold.
    """
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    largest = max(contours, key=cv2.contourArea)
    area = cv2.contourArea(largest)
    if area < config.MIN_BLOB_AREA_PX:
        return None

    moments = cv2.moments(largest)
    if moments["m00"] == 0:
        return None

    cx = moments["m10"] / moments["m00"]
    cy = moments["m01"] / moments["m00"]
    return cx, cy, area


def find_ball(frame_bgr):
    """
    Locate the tennis ball in a frame. Returns (cx, cy, area) in pixel
    coordinates, or None if not found.
    """
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, config.TENNIS_BALL_HSV_LOW, config.TENNIS_BALL_HSV_HIGH)
    # Clean up small speckle noise from the threshold
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    return _largest_blob_centroid(mask)


def find_goal(frame_bgr):
    """
    Locate the goal-color patch in a frame. Handles hue wraparound (e.g.
    red) by combining two HSV ranges from config. Returns (cx, cy, area)
    in pixel coordinates, or None if not found.
    """
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, config.GOAL_HSV_LOW_1, config.GOAL_HSV_HIGH_1)
    mask2 = cv2.inRange(hsv, config.GOAL_HSV_LOW_2, config.GOAL_HSV_HIGH_2)
    mask = cv2.bitwise_or(mask1, mask2)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    return _largest_blob_centroid(mask)


def pixel_offset_to_bearing(cx: float, frame_width: int, hfov_deg: float) -> float:
    """
    Convert a blob's horizontal pixel center `cx` into a bearing angle
    relative to the camera's centerline, in degrees.

    This assumes a roughly linear (pinhole-like) mapping across the
    field of view, which is a fine approximation for a standard lens
    across a moderate FOV -- it will be measurably off at the extreme
    edges of a wide-angle/fisheye lens, but that's fine for this task
    since you only need coarse bearing accuracy for a discrete panel
    trim, not precision optics.
    """
    frame_center = frame_width / 2.0
    pixel_offset = cx - frame_center
    fraction_of_half_fov = pixel_offset / frame_center
    return fraction_of_half_fov * (hfov_deg / 2.0)


def get_ball_bearing(frame_bgr):
    """Convenience wrapper: returns ball bearing in degrees, or None."""
    result = find_ball(frame_bgr)
    if result is None:
        return None
    cx, _, _ = result
    return pixel_offset_to_bearing(cx, frame_bgr.shape[1], config.CAMERA_HFOV_DEG)


def get_goal_bearing(frame_bgr):
    """Convenience wrapper: returns goal bearing in degrees, or None."""
    result = find_goal(frame_bgr)
    if result is None:
        return None
    cx, _, _ = result
    return pixel_offset_to_bearing(cx, frame_bgr.shape[1], config.CAMERA_HFOV_DEG)


if __name__ == "__main__":
    # Quick manual test: run this on the Pi (or a laptop with a webcam)
    # to see live ball/goal detection and bearing numbers printed to
    # the console. Press 'q' in the preview window to quit.
    cap = open_capture()
    print("Press 'q' to quit.")
    try:
        while True:
            frame = read_frame(cap)
            if frame is None:
                print("Failed to read frame, stopping.")
                break

            ball_bearing = get_ball_bearing(frame)
            goal_bearing = get_goal_bearing(frame)

            ball_txt = f"{ball_bearing:+.1f} deg" if ball_bearing is not None else "not found"
            goal_txt = f"{goal_bearing:+.1f} deg" if goal_bearing is not None else "not found"
            print(f"ball: {ball_txt:>14} | goal: {goal_txt:>14}", end="\r")

            cv2.imshow("AutoTarget camera test", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()
