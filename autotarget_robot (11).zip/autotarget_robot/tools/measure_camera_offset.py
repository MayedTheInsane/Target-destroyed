"""
Measure CAMERA_YAW_OFFSET_DEG (how far the camera is turned from the robot's
forward axis).

1. Put the robot on the floor with the panel servo at SERVO_CENTER_DEG
   (python3 servo_control.py, then Ctrl+C leaves it centered), so the panel
   normal points along robot-forward.
2. Place the tennis ball (or goal patch) exactly along that forward line, e.g.
   2 m straight out from the panel's pivot, measured with a tape and a string
   along the panel normal.
3. Run:  python3 tools/measure_camera_offset.py          (ball, default)
         python3 tools/measure_camera_offset.py --goal
It averages the camera's reported bearing for that target and prints the
offset to put in config.py. If the camera were perfectly aligned it would read 0.
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import config  # noqa: E402
import camera_tracker  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--goal", action="store_true", help="measure with the goal patch instead of the ball")
    ap.add_argument("--frames", type=int, default=40)
    args = ap.parse_args()
    get = camera_tracker.get_goal_bearing if args.goal else camera_tracker.get_ball_bearing

    cap = camera_tracker.open_capture()
    vals = []
    try:
        t0 = time.time()
        while len(vals) < args.frames and time.time() - t0 < 60:
            frame, outputs = camera_tracker.read_frame(cap)
            b = get(frame, outputs) if frame is not None else None
            if b is not None:
                vals.append(b)
                print(f"  {len(vals)}/{args.frames}  bearing {b:+.2f}", end="\r")
    finally:
        cap.stop()
    if len(vals) < 5:
        sys.exit("\nTarget seen in too few frames -- is it in view and detected?")
    vals.sort()
    med = vals[len(vals) // 2]
    print(f"\nCamera reports the forward-line target at {med:+.2f} deg "
          f"(spread {vals[-1] - vals[0]:.2f}).")
    print(f"Set in config.py:  CAMERA_YAW_OFFSET_DEG = {-med:+.2f}")


if __name__ == "__main__":
    main()
