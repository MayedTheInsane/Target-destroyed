# AutoTarget robot control code

Code sketch for the ball-redirection robot: camera-based bearing tracking
+ reflection-angle math + servo panel control.

## Files

- `config.py` -- all tunable constants (camera FOV, IMX500 model path/
  class indices, HSV thresholds, detection/fusion mode, servo pins/
  limits, loop rate). Start here.
- `reflection.py` -- pure geometry, no hardware. Turns (incoming ball
  bearing, goal bearing) into the panel angle that reflects one into the
  other. Run `python3 reflection.py` to sanity-check the math.
- `camera_tracker.py` -- finds the ball and the goal patch using BOTH
  detectors on every frame from the Raspberry Pi AI Camera: the IMX500
  on-sensor neural network and OpenCV HSV color thresholding, then
  fuses them (see "Combined detection" below) and converts the result
  to a bearing angle. Run `python3 camera_tracker.py` (add `--preview`
  for a window) to see what each detector sees side by side.
- `camera_tracker_hsv_only_backup.py`, `camera_tracker_nn_only_backup.py`
  -- the previous single-detector versions, kept for rollback only.
  Nothing imports them.
- `servo_control.py` -- PCA9685-based servo driver wrapper. Defines
  `PanelServo` (the main reflector servo) and `CameraPanServo` (a second,
  small servo -- e.g. an SG90 -- that swivels the camera during
  calibration only, on its own PCA9685 channel). Run with `--sim` to
  test without hardware, or without it to sweep a real servo.
- `main.py` -- ties it together: calibration phase (actively pan the
  camera to find the goal bearing) then a live loop (track the ball,
  update the panel angle in real time). The camera pan servo only moves
  during calibration -- it's locked to a fixed angle before the live
  loop starts and is never touched again.
- `tools/hsv_tuner.py` -- interactive slider tool for finding the HSV
  thresholds for the ball and goal color, reading frames from the AI
  camera (or `--image photo.jpg`). Re-tune with the AI camera itself --
  thresholds found with a USB webcam won't carry over exactly.

## Combined detection (NN + HSV)

Every frame is run through both detectors, per target (ball, goal),
and `config.DETECTION_MODE_BALL` / `DETECTION_MODE_GOAL` choose how
they are combined:

| mode | behavior |
|---|---|
| `"fused"` (default) | Both agree (horizontal centers within `FUSION_AGREE_TOL_FRAC` of the frame width) -> weighted average (`FUSION_NN_WEIGHT`). Only one sees it -> use that one. Both see it but disagree -> `FUSION_PRIMARY` wins. |
| `"nn_only"` | Neural network only. |
| `"hsv_only"` | Color threshold only; needs no model file. |

Why this helps: the two fail differently. HSV is fooled by look-alike
colors and by lighting shifts; the NN can miss a target it wasn't
trained on enough views of. When one drops out the other covers, and
when they conflict, the one you trust more (default: the NN) decides.

Safety nets: if the model file isn't there yet, or the NN output can't
be parsed, `"fused"` targets quietly fall back to HSV-only with a printed
warning, so the robot works (HSV-only) before any model is trained.
A target set to `"nn_only"` instead refuses to start without the model.

## Training and deploying the detection model

The NN half of the pipeline needs a model trained *before* it can run
(the HSV half works without one, so you can test everything else in the
meantime). Roughly, in order:

1. **Collect images.** Photograph the tennis ball and the goal patch
   from the camera's actual mounted viewpoint, under lighting as close
   to the competition venue as you can get. Get variety: different
   distances, angles, and a good number of "background only" frames
   with neither object present.
2. **Label them.** Draw bounding boxes around the ball and the goal
   patch in each image with a labeling tool (e.g. CVAT, LabelImg,
   Roboflow). Keep the class order consistent -- whatever order you
   assign here is what `IMX500_BALL_CLASS_INDEX` / `IMX500_GOAL_CLASS_INDEX`
   in `config.py` must match.
3. **Train a detector.** Use a lightweight architecture supported by
   the IMX500 toolchain (NanoDet is what `camera_tracker.py` assumes --
   see its module docstring). Sony/Raspberry Pi publish transfer-learning
   recipes for this rather than training from scratch.
4. **Convert for the IMX500.** Run the trained model through Sony's
   IMX500 conversion toolchain to produce a `.rpk` network package --
   this is the on-sensor-deployable format, not the raw training
   checkpoint.
5. **Deploy.** Copy the `.rpk` file onto the Pi and point
   `config.IMX500_MODEL_PATH` at it.
6. **Verify class indices.** Set `IMX500_BALL_CLASS_INDEX` and
   `IMX500_GOAL_CLASS_INDEX` in `config.py` to match the label order
   from step 2 -- these are arbitrary to your training data, not a
   fixed standard.

None of this happens automatically -- steps 1-4 are offline work you do
ahead of the competition, well before any of the Python files here get
run.

## Setup on the Raspberry Pi

```bash
sudo apt install -y imx500-all libopenblas0     # IMX500 firmware + demo models; OpenCV's BLAS library
pip install --break-system-packages picamera2 opencv-python numpy \
    adafruit-circuitpython-pca9685 adafruit-circuitpython-motor adafruit-blinka
```

(`picamera2` is usually already present on Raspberry Pi OS; skip it from
the pip line if so.) Enable I2C via `raspi-config` if you haven't already
(needed for the PCA9685 servo driver board), and enable the IMX500 camera
overlay per the Raspberry Pi AI Camera setup guide.

## Suggested order of testing

1. `python3 reflection.py` -- confirms the trig is right (no hardware needed).
2. `python3 servo_control.py --sim` then without `--sim` on the Pi --
   confirms wiring/direction of the real servo before anything else
   depends on it.
3. `python3 tools/hsv_tuner.py` -- tune the ball and goal HSV ranges on
   the AI camera and copy the printed values into `config.py`. This
   half works today with no trained model.
4. `python3 camera_tracker.py --preview` -- with no model deployed it
   prints a warning and runs HSV-only; confirm the HSV side is solid
   first. Columns show NN / HSV / fused x-positions per target.
5. Train and deploy the detection model (see above), point
   `IMX500_MODEL_PATH` at it, and set the class indices. Hold the ball
   and goal patch in view in step 4's output: the raw NN detections
   list shows each class index and label, so you can read the right
   indices straight off the screen. Then confirm the source column
   shows `both` when the two detectors agree.
6. `python3 main.py` -- full calibration + live loop. Use `--sim` if you
   want to test the servo-command flow/timing without moving the real
   panel servo yet (the camera/model still need to be real either way).

## Known gaps to fill in before competition

- `config.py`'s `CAMERA_HFOV_DEG`, `SERVO_CENTER_DEG`, and
  `CAMERA_PAN_CENTER_DEG` are placeholders -- measure/calibrate these
  against your actual camera and mechanical zero-points.
- `IMX500_MODEL_PATH`, `IMX500_BALL_CLASS_INDEX`, and
  `IMX500_GOAL_CLASS_INDEX` are all placeholders until you've actually
  trained, converted, and deployed a model -- see "Training and
  deploying the detection model" above.
- `IMX500_MIN_CONFIDENCE` hasn't been tuned against a real trained
  model yet -- start conservative and adjust once you can see real
  detection scores.
- The fusion settings (`FUSION_AGREE_TOL_FRAC`, `FUSION_NN_WEIGHT`,
  `FUSION_PRIMARY`) are reasonable defaults, not tuned values. Watch
  the `source` column in `camera_tracker.py`'s output on the real
  floor: lots of `nn*`/`hsv*` (disagreement) means one detector needs
  fixing, or the tolerance is too tight.
- The fusion and parsing logic has been tested off the Pi with
  synthetic frames and a stand-in IMX500 object, but never against
  the real sensor. `_parse_nn_detections()` in `camera_tracker.py`
  follows picamera2's own `imx500_object_detection_demo.py`; if your
  trained model's outputs differ, compare against that script on your
  Pi. A parsing failure disables the NN for the run (HSV carries on)
  and prints a warning, so look for it in the console.
- `CAMERA_PAN_CHANNEL` assumes the pan servo is on a second, separate
  PCA9685 channel (channel 1, alongside the panel servo's channel 0) on
  the *same* board -- if you wire it to a second board or a different
  channel, update that constant. Also size a small 5V supply for the
  pan servo (an SG90 draws far less than the RDS3218, but still don't
  pull it from the Pi's own 5V rail if you can avoid it).
- No obstacle/edge-case handling yet for the ball briefly leaving the
  frame mid-approach -- currently it just holds the last angle, which is
  a reasonable default but worth testing against real ball speeds.
- `main.py` now transitions from calibration straight into the live
  trial with no manual prompt, per the competition's no-intervention
  rule -- double check the calibration scan reliably finds the goal
  before relying on that in a real run.
