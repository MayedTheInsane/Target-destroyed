"""
Central configuration for the AutoTarget robot.

Tune the values in this file to match your actual hardware and the
competition floor/lighting, rather than editing constants scattered
through the other modules.
"""

# ----------------------------------------------------------------------
# Camera -- Raspberry Pi AI Camera (IMX500)
# ----------------------------------------------------------------------
FRAME_WIDTH = 320              # keep resolution modest -> faster loop on a Pi
FRAME_HEIGHT = 240
CAMERA_HFOV_DEG = 66.3          # IMX500 datasheet HFOV (+/-3 deg) -- confirm
                                # against your actual module/lens once mounted

# The BALL is found by the stock COCO object-detection model that comes
# with the AI camera (installed by `sudo apt install imx500-all`), using
# its "sports ball" class. The GOAL does not use the NN: it is found by
# HSV color thresholding (next section).
IMX500_MODEL_PATH = "/usr/share/imx500-models/imx500_network_ssd_mobilenetv2_fpnlite_320x320_pp.rpk"

# Which NN class is the ball. Leave the index as None to look it up by
# label name in the model's own label list (the way picamera2's demo does),
# which avoids hard-coding a number that differs between COCO numbering
# schemes. Set an int only to override the lookup, e.g. after reading the
# class number off `python3 camera_tracker.py`'s output.
IMX500_BALL_LABEL = "sports ball"
IMX500_BALL_CLASS_INDEX = None
IMX500_GOAL_CLASS_INDEX = None  # unused while the goal is HSV-only; only set this
                                # if you switch DETECTION_MODE_GOAL to use a
                                # custom-trained model that has a goal class

# Output-format overrides for models that don't describe their own output.
# They mirror the --bbox-normalization / --bbox-order / --ignore-dash-labels
# flags of picamera2's imx500_object_detection_demo.py. Leave them None to
# use whatever the model provides; set them only if the boxes drawn by
# `python3 camera_tracker.py --preview` land in the wrong place or the
# printed labels look shifted by a few entries.
IMX500_BBOX_NORMALIZATION = None   # True / False
IMX500_BBOX_ORDER = None           # "yx" or "xy"
IMX500_IGNORE_DASH_LABELS = None   # True / False

IMX500_MIN_CONFIDENCE = 0.4    # detection confidence threshold. A small, fast
                                # tennis ball may score modestly with the stock
                                # model, so this starts lower than usual; tune on
                                # real footage (too low = false balls, too high =
                                # missed balls)

# ----------------------------------------------------------------------
# HSV color-threshold detection -- runs on the CPU on the camera frame.
# It finds the GOAL patch (and can also back up the ball, see
# DETECTION_MODE_* below).
#
# These values depend on the camera and lighting, and the AI camera's
# color response differs from a USB webcam's, so re-tune them with
# tools/hsv_tuner.py on the real camera, ideally on the competition floor.
# ----------------------------------------------------------------------
TENNIS_BALL_HSV_LOW = (29, 86, 6)
TENNIS_BALL_HSV_HIGH = (64, 255, 255)
# Example values below are for a RED goal. Red wraps around the HSV hue
# circle, so it needs two ranges; for any other color set range 2 to
# something that can never match, e.g. LOW_2 = HIGH_2 = (0, 0, 0).
GOAL_HSV_LOW_1 = (0, 120, 70)
GOAL_HSV_HIGH_1 = (10, 255, 255)
GOAL_HSV_LOW_2 = (170, 120, 70)
GOAL_HSV_HIGH_2 = (180, 255, 255)
MIN_BLOB_AREA_PX = 25

# ----------------------------------------------------------------------
# How the two detectors are combined, per target (ball / goal):
#   "fused"    run both. If they agree, average them; if only one sees
#              the target, use that one; if both see it but disagree,
#              FUSION_PRIMARY wins.
#   "nn_only"  neural network only.
#   "hsv_only" color threshold only (needs no model file at all).
#
# Current setup: ball = NN only (stock "sports ball"), goal = HSV only.
# A target set to "nn_only" refuses to start if the model can't be
# loaded. If you later want HSV as a backup for the ball, set
# DETECTION_MODE_BALL = "fused": then, if the NN can't load or its output
# can't be parsed, the ball degrades to HSV-only with a printed warning
# instead of leaving the robot blind.
# ----------------------------------------------------------------------
DETECTION_MODE_BALL = "nn_only"
DETECTION_MODE_GOAL = "hsv_only"

FUSION_AGREE_TOL_FRAC = 0.10   # detectors "agree" when their horizontal centers
                                # are within this fraction of the frame width
                                # (0.10 = 32 px at 320 px wide, about 6.6 deg)
FUSION_NN_WEIGHT = 0.5         # when they agree: 1.0 = trust NN position only,
                                # 0.0 = HSV only, 0.5 = plain average
FUSION_PRIMARY = "nn"          # who wins a disagreement: "nn" or "hsv". "nn"
                                # filters out look-alike colors; choose "hsv"
                                # if your model is the less trustworthy one

# ----------------------------------------------------------------------
# Servo (panel yaw axis, driven directly from a Raspberry Pi GPIO pin)
#
# Set for the Hitec HS-311 (standard-size analog servo), using the same
# numbers as your bench test (servodatabase.com):
#   rotation: 120 deg | pulse width: 575-2460us
#   operating voltage: 4.8-6.0V
#   torque ~3.0 kg.cm at 4.8V, ~3.7 kg.cm at 6V (about a sixth of the old
#   RDS3218 -- keep the panel and its bracket light)
#   speed ~0.19 s/60deg at 4.8V, ~0.15 s/60deg at 6V
#
# The servo only turns 120 degrees, so every angle below runs 0-120
# (NOT 0-180) and servo_control.py tells gpiozero that range.
#
# SERVO_CENTER_DEG is 60.0 (the midpoint of 0-120) as a starting default --
# confirm this against your actual mechanical zero-point once the panel
# is mounted on the horn, since the true center depends on how the horn
# happens to sit when you bolt it on, not just the math midpoint.
# ----------------------------------------------------------------------
PANEL_GPIO_PIN = 17            # BCM numbering: GPIO17 = physical pin 11 (the pin your
                               # bench test used)
USE_PIGPIO = True              # steadier PWM through the pigpiod daemon (see the setup
                               # notes in servo_control.py); False = gpiozero's default
                               # software PWM, which can jitter under CPU load
SERVO_MIN_PULSE_US = 575
SERVO_MAX_PULSE_US = 2460
SERVO_MIN_ANGLE_DEG = 0.0      # keep at 0: angles are measured from the min-pulse end
SERVO_MAX_ANGLE_DEG = 120.0    # HS-311 total travel
SERVO_CENTER_DEG = 60.0        # panel angle that corresponds to panel-normal=0 (forward);
                               # confirm/adjust from your mechanical zero-point

# Panel angle safety clamp -- keep some margin off the mechanical end-stops.
# With center 60 this leaves the panel normal +-55 deg either side of forward.
PANEL_MIN_DEG = 5.0
PANEL_MAX_DEG = 115.0

# Electrical characteristics, used only as documentation/reference for
# sizing the power supply and your BOM -- not read by any code path.
# The stall figure is a conservative sizing estimate, NOT a datasheet
# number; check the HS-311 datasheet before finalizing the supply.
SERVO_STALL_CURRENT_A = 1.0     # worst-case stall draw per servo (amps)
SERVO_OPERATING_VOLTAGE_V = (4.8, 6.0)  # min/max safe supply voltage

# ----------------------------------------------------------------------
# Control loop
# ----------------------------------------------------------------------
# Calibration: the camera is FIXED (no pan servo, no sweeping). The goal has
# to be inside the camera's field of view; calibration just watches the feed,
# collects CALIBRATION_SAMPLES goal sightings and locks in their median.
CALIBRATION_TIMEOUT_S = 300       # competition limit: 5 minutes
CALIBRATION_SAMPLES = 20          # goal sightings to collect before locking in
CALIBRATION_MAX_SPREAD_DEG = 3.0  # warn if the sightings disagree by more than this
LIVE_LOOP_HZ = 15                 # camera+control loop rate during a trial
BEARING_SMOOTHING_ALPHA = 0.5     # exponential smoothing factor (0=no update, 1=no smoothing)
