"""
Pure geometry: turns two bearings (incoming ball, goal) into the panel
angle that redirects one into the other, via the law of reflection.

Everything here is plain math with no hardware dependencies, so you can
unit-test it on a laptop before ever touching the Pi.

Convention used throughout this project:
    All bearings are in DEGREES, measured relative to the robot's own
    forward-facing axis (i.e. camera-centerline = 0 deg), positive to the
    robot's right, negative to the robot's left. This is exactly what a
    camera pixel-offset calculation naturally gives you -- see
    camera_tracker.py's `pixel_offset_to_bearing()`.
"""

import math


def panel_angle_from_bearings(incoming_bearing_deg: float, goal_bearing_deg: float) -> float:
    """
    Compute the panel yaw angle that reflects a ball arriving from
    `incoming_bearing_deg` toward `goal_bearing_deg`.

    Law of reflection: angle of incidence = angle of reflection, both
    measured from the panel's normal. Equivalently, the panel's normal
    must point exactly along the bisector of the incoming-ball direction
    and the to-goal direction.

    Both inputs are bearings *relative to the robot*, in degrees, using
    the convention documented in the module docstring.

    Returns the panel normal's bearing, in the same relative-to-robot
    frame (0 = facing forward, positive = right).
    """
    # The direction the ball is travelling *away* from its source and
    # toward the robot is 180 degrees from where it's arriving from, but
    # since we treat "incoming_bearing_deg" as "the direction I should look
    # to see where it's coming from," the reflection bisector is simply
    # the average of the two bearings (this falls out of the vector
    # bisector formula for two rays sharing the same origin).
    normal_bearing = (incoming_bearing_deg + goal_bearing_deg) / 2.0
    return normal_bearing


def servo_angle_from_panel_normal(panel_normal_bearing_deg: float, servo_center_deg: float) -> float:
    """
    Convert a panel-normal bearing (relative to robot, 0 = forward) into
    an absolute servo command angle, using the mechanical zero-point
    calibration value `servo_center_deg` (the servo angle at which the
    panel normal points exactly forward).
    """
    return servo_center_deg + panel_normal_bearing_deg


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


if __name__ == "__main__":
    # Quick sanity checks you can run with: python3 reflection.py
    cases = [
        (0.0, 0.0, 0.0),      # ball straight ahead, goal straight ahead -> straight bounce back
        (-30.0, 30.0, 0.0),   # symmetric case -> panel normal straight ahead
        (-20.0, 10.0, -5.0),  # asymmetric case
    ]
    for incoming, goal, expected in cases:
        result = panel_angle_from_bearings(incoming, goal)
        status = "OK" if math.isclose(result, expected, abs_tol=1e-6) else "FAIL"
        print(f"[{status}] incoming={incoming:+.1f} goal={goal:+.1f} "
              f"-> panel_normal={result:+.1f} (expected {expected:+.1f})")
