"""
Servo control straight from the Raspberry Pi's GPIO pins, via gpiozero.

Setup on the Pi (once):
    sudo apt install -y python3-gpiozero pigpio python3-pigpio
    sudo systemctl enable --now pigpiod

Why pigpio: gpiozero's default software PWM is timed by the Pi's CPU, so
the servo can twitch or buzz whenever the Pi gets busy -- and this robot
is busy (camera + neural network + control loop). The pigpiod daemon
generates the pulses with DMA timing instead, which is far steadier. If
pigpiod isn't running this module still works, but prints a warning and
falls back to the default software PWM.

Wiring (BCM pin numbers, set in config.py):
    servo signal (orange/yellow) -> the GPIO pin from config.py
    servo power (red)            -> its OWN 4.8-6V supply, NOT the Pi's 5V pin
    servo ground (black/brown)   -> that supply's ground AND a Pi ground pin
                                    (grounds must be shared or the signal
                                    has no reference)

The panel servo is the Hitec HS-311 (see config.py for its numbers). It
only turns 120 degrees, not the 180 that most servo code assumes, so
every servo here is given an explicit `actuation_range` -- without it a
commanded 60 deg would land at the wrong pulse width. If the servo stalls
against the panel it draws far more than when moving
(config.SERVO_STALL_CURRENT_A is a conservative sizing figure), so size
the servo supply for that peak, not its average draw.
"""

import config

_pin_factory_state = {"resolved": False, "factory": None}


def _shared_pin_factory():
    """
    One pin factory shared by every servo. Returns a pigpio factory if
    config.USE_PIGPIO is set and pigpiod is reachable, otherwise None
    (which tells gpiozero to use its default factory).
    """
    if not _pin_factory_state["resolved"]:
        _pin_factory_state["resolved"] = True
        if config.USE_PIGPIO:
            try:
                from gpiozero.pins.pigpio import PiGPIOFactory

                _pin_factory_state["factory"] = PiGPIOFactory()
            except Exception as exc:  # noqa: BLE001 -- any failure should degrade, not crash
                print(
                    f"[servo_control] WARNING: could not use pigpio ({exc!r}). "
                    "Falling back to software PWM, which can jitter under CPU load. "
                    "Fix: sudo systemctl enable --now pigpiod"
                )
    return _pin_factory_state["factory"]


class _GPIOServo:
    """
    Thin wrapper around one servo on a GPIO pin, exposing
    set_angle(degrees) clamped to a given [min_deg, max_deg] range.
    PanelServo and CameraPanServo below are just this with their own
    pin/pulse-width/limit numbers plugged in.
    """

    def __init__(
        self,
        pin: int,
        min_pulse_us: int,
        max_pulse_us: int,
        min_deg: float,
        max_deg: float,
        center_deg: float,
        simulate: bool = False,
        label: str = "servo",
        actuation_range: float = 180.0,
    ):
        # actuation_range = how many degrees of travel the servo has between
        # its min and max pulse width (HS-311: 120, most hobby servos: 180).
        # Commanded angles run 0..actuation_range, so every limit below
        # must sit inside that span or the servo would be driven wrong.
        if not (0 <= min_deg <= center_deg <= max_deg <= actuation_range):
            raise ValueError(
                f"{label}: need 0 <= min ({min_deg}) <= center ({center_deg}) <= "
                f"max ({max_deg}) <= actuation_range ({actuation_range}) -- "
                "check the servo settings in config.py."
            )
        self.simulate = simulate
        self._min_deg = min_deg
        self._max_deg = max_deg
        self._center_deg = center_deg
        self._label = label
        self._last_angle = center_deg

        if self.simulate:
            # Lets you develop/test the control logic on a laptop with
            # no hardware attached -- set_angle() just prints and stores.
            return

        from gpiozero import AngularServo

        # initial_angle=center so the servo powers up at its centre rather
        # than swinging to the 0-degree end-stop first.
        self._servo = AngularServo(
            pin,
            initial_angle=center_deg,
            min_angle=0,
            max_angle=actuation_range,
            min_pulse_width=min_pulse_us / 1_000_000,
            max_pulse_width=max_pulse_us / 1_000_000,
            pin_factory=_shared_pin_factory(),
        )

    def set_angle(self, degrees: float):
        """Command the servo to an absolute angle, clamped for safety."""
        clamped = max(self._min_deg, min(self._max_deg, degrees))
        self._last_angle = clamped

        if self.simulate:
            print(f"[SIM] {self._label} -> {clamped:.1f} deg")
            return

        self._servo.angle = clamped

    def get_last_angle(self) -> float:
        return self._last_angle

    def center(self):
        self.set_angle(self._center_deg)

    def release(self):
        """Stop sending pulses (servo goes limp). Not used during a run."""
        if not self.simulate:
            self._servo.detach()


class PanelServo(_GPIOServo):
    """
    The main reflector-panel yaw servo (the HS-311). Runs throughout
    calibration and the live trial.
    """

    def __init__(self, pin: int = config.PANEL_GPIO_PIN, simulate: bool = False):
        super().__init__(
            pin=pin,
            min_pulse_us=config.SERVO_MIN_PULSE_US,
            max_pulse_us=config.SERVO_MAX_PULSE_US,
            min_deg=config.PANEL_MIN_DEG,
            max_deg=config.PANEL_MAX_DEG,
            center_deg=config.SERVO_CENTER_DEG,
            simulate=simulate,
            label="panel servo",
            actuation_range=config.SERVO_MAX_ANGLE_DEG - config.SERVO_MIN_ANGLE_DEG,
        )


class CameraPanServo(_GPIOServo):
    """
    Small, cheap servo (e.g. an SG90) on its own GPIO pin that swivels
    the camera to actively scan for the goal color during calibration
    only -- see the CAMERA_PAN_* comment block in config.py. It is locked
    at its center angle before the live trial starts and is never
    commanded again during ball tracking.
    """

    def __init__(self, pin: int = config.CAMERA_PAN_GPIO_PIN, simulate: bool = False):
        super().__init__(
            pin=pin,
            min_pulse_us=config.CAMERA_PAN_MIN_PULSE_US,
            max_pulse_us=config.CAMERA_PAN_MAX_PULSE_US,
            min_deg=config.CAMERA_PAN_MIN_DEG,
            max_deg=config.CAMERA_PAN_MAX_DEG,
            center_deg=config.CAMERA_PAN_CENTER_DEG,
            simulate=simulate,
            label="camera pan servo",
            actuation_range=config.CAMERA_PAN_MAX_DEG - config.CAMERA_PAN_MIN_DEG,
        )


if __name__ == "__main__":
    # Bench test: sweeps the panel servo across its safe range so you can
    # visually confirm wiring/direction before trusting it in the full
    # control loop. Run with --sim on a laptop with no hardware.
    import sys
    import time

    sim = "--sim" in sys.argv
    panel = PanelServo(simulate=sim)

    print("Sweeping panel angle. Ctrl+C to stop.")
    try:
        while True:
            for angle in range(int(config.PANEL_MIN_DEG), int(config.PANEL_MAX_DEG) + 1, 2):
                panel.set_angle(angle)
                time.sleep(0.03)
            for angle in range(int(config.PANEL_MAX_DEG), int(config.PANEL_MIN_DEG) - 1, -2):
                panel.set_angle(angle)
                time.sleep(0.03)
    except KeyboardInterrupt:
        panel.center()
        time.sleep(0.5)  # let it get there before the pulses stop
        panel.release()
        print("\nStopped, panel re-centered and released.")
