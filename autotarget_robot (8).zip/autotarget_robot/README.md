# AutoTarget robot control code

Code sketch for the ball-redirection robot: camera-based bearing tracking
+ reflection-angle math + servo panel control.

## How it works

- **Ball** -- found by the Raspberry Pi AI Camera's on-sensor neural
  network, using the **"sports ball"** class of the stock COCO
  object-detection model that ships with the camera.
- **Goal patch** -- found by OpenCV **HSV color thresholding** on the
  same camera frame.
- **Panel** -- an HS-311 servo wired straight to a Pi GPIO pin turns the
  panel so that its normal bisects the ball and goal bearings (law of
  reflection), updated every frame.

## Files

- `config.py` -- all tunable constants (camera FOV, NN model/ball label,
  HSV thresholds, detection mode, servo pins/limits, loop rate). Start here.
- `reflection.py` -- pure geometry, no hardware. Turns (incoming ball
  bearing, goal bearing) into the panel angle that reflects one into the
  other. Run `python3 reflection.py` to sanity-check the math.
- `camera_tracker.py` -- runs the NN and HSV detectors on each frame and
  converts the chosen position to a bearing angle (0 = camera centerline,
  + = right). Run `python3 camera_tracker.py` (add `--preview` for a
  window) to see what each detector sees.
- `camera_tracker_hsv_only_backup.py`, `camera_tracker_nn_only_backup.py`
  -- the previous single-detector versions, kept for rollback only.
  Nothing imports them.
- `servo_control.py` -- drives servos directly from GPIO pins with
  gpiozero (through the pigpio daemon for steady pulses). Defines
  `PanelServo` (the HS-311 reflector) and `CameraPanServo` (a second,
  small servo -- e.g. an SG90 -- that swivels the camera during
  calibration only). Run `python3 servo_control.py` to sweep the panel
  servo on the bench, or add `--sim` to test without hardware.
- `main.py` -- ties it together: calibration phase (actively pan the
  camera to find the goal bearing) then a live loop (track the ball,
  update the panel angle in real time). The camera pan servo only moves
  during calibration -- it's locked to a fixed angle before the live
  loop starts and is never touched again.
- `tools/hsv_tuner.py` -- interactive slider tool for finding the HSV
  thresholds for the goal color (and ball, if you ever use it), reading
  frames from the AI camera (or `--image photo.jpg`). Re-tune with the AI
  camera itself -- thresholds found with a USB webcam won't carry over.

## Detection modes

`config.DETECTION_MODE_BALL` and `DETECTION_MODE_GOAL` choose, per
target, how the two detectors are used. Shipped setting: ball
`"nn_only"`, goal `"hsv_only"`.

| mode | behavior |
|---|---|
| `"nn_only"` | Neural network only. Refuses to start if the model can't be loaded. |
| `"hsv_only"` | Color threshold only; needs no model file. |
| `"fused"` | Both. If they agree (horizontal centers within `FUSION_AGREE_TOL_FRAC` of the frame width) the result is a weighted average (`FUSION_NN_WEIGHT`); if only one sees the target, that one is used; if both see it but disagree, `FUSION_PRIMARY` wins. If the model can't load or its output can't be parsed, it degrades to HSV-only with a printed warning. |

If the stock model turns out to miss the ball too often (see "Known
gaps"), the cheapest fallback is `DETECTION_MODE_BALL = "fused"` with the
ball's HSV range tuned in `tools/hsv_tuner.py`: HSV then covers frames
where the NN sees nothing. A custom-trained model with its own ball and
goal classes is also possible later -- point `IMX500_MODEL_PATH` at the
converted `.rpk` and set `IMX500_BALL_CLASS_INDEX` /
`IMX500_GOAL_CLASS_INDEX`.

### How the ball's class is found

The stock model's class numbers differ between COCO numbering schemes,
so `camera_tracker.py` doesn't hard-code one. At start-up it looks up
`IMX500_BALL_LABEL` (`"sports ball"`) in the model's own label list, or
in a built-in COCO list if the model carries none, and prints what it
chose, e.g. `Ball = 'sports ball' -> NN class 32 (from ...)`. Set
`IMX500_BALL_CLASS_INDEX` to override it.

## Setup on the Raspberry Pi

```bash
sudo apt install -y imx500-all libopenblas0 python3-gpiozero pigpio python3-pigpio
sudo systemctl enable --now pigpiod        # steady servo pulses; starts on every boot
pip install --break-system-packages opencv-python numpy
```

(`picamera2` ships with Raspberry Pi OS; install it with apt if missing.)
Enable the IMX500 camera per the Raspberry Pi AI Camera setup guide.
`imx500-all` installs the stock models under `/usr/share/imx500-models/`,
including the one `config.IMX500_MODEL_PATH` points at. No I2C setup is
needed any more -- the PCA9685 board is gone.

### Wiring (BCM pin numbers, set in `config.py`)

| servo | signal pin | power |
|---|---|---|
| HS-311 panel | GPIO17 (physical pin 11) -- `PANEL_GPIO_PIN` | its OWN 4.8-6 V supply |
| camera pan (SG90 or similar) | GPIO27 (physical pin 13) -- `CAMERA_PAN_GPIO_PIN` | its OWN 5 V supply |

Servo power must NOT come from the Pi's 5 V pin (a stalled servo can
brown out the Pi). Join the servo supply's ground to a Pi ground pin, or
the signal has no reference and the servo will jitter or ignore it. The
Pi's 3.3 V signal level is fine for these servos.

## Suggested order of testing

1. `python3 reflection.py` -- confirms the trig is right (no hardware needed).
2. `python3 servo_control.py` on the Pi -- sweeps the panel servo so you
   can confirm wiring, direction, and that it isn't buzzing. If it
   prints a pigpio warning, run `sudo systemctl enable --now pigpiod`.
3. `python3 tools/hsv_tuner.py` -- tune the goal color's HSV range on
   the AI camera and copy the printed values into `config.py`.
4. `python3 camera_tracker.py --preview` -- hold a tennis ball in view.
   The NN column should show a detection labelled `sports ball` (or the
   class number the start-up line printed) and the preview window draws
   its box; the goal patch should show up in the HSV column.
5. `python3 main.py` -- full calibration + live loop. Use `--sim` to test
   the servo-command flow without moving the real servos (the camera
   and model still need to be real either way).

## Known gaps to fill in before competition

- **Stock model vs. a tennis ball (the biggest risk).** The ball is
  found only by a generic COCO model, which was not trained for a small,
  fast tennis ball. It may miss it at distance or when it's blurred.
  Check how reliably step 4 above detects a rolling ball at the real
  distances; if it's poor, lower `IMX500_MIN_CONFIDENCE`, or move to
  `"fused"` (above), or train a custom model.
- **Never run against real hardware.** The detection, label lookup,
  fusion, servo driver and main loop have been tested off the Pi using
  stand-ins for picamera2, the IMX500 and gpiozero -- not the real
  libraries or devices. `_parse_nn_detections()` follows picamera2's
  `imx500_object_detection_demo.py`. If boxes land in the wrong place or
  labels look shifted, try the `IMX500_BBOX_*` / `IMX500_IGNORE_DASH_LABELS`
  overrides in `config.py`, and compare with that demo script on your Pi.
  If the NN output can't be parsed, the NN is switched off for the run
  with a warning -- and with the ball set to `"nn_only"` the robot then
  sees no ball, so watch the console.
- `config.py`'s `CAMERA_HFOV_DEG`, `SERVO_CENTER_DEG`, and
  `CAMERA_PAN_CENTER_DEG` are placeholders -- measure/calibrate these
  against your actual camera and mechanical zero-points.
- **Camera pan servo pin.** `CAMERA_PAN_GPIO_PIN = 27` is an assumption
  made when the PCA9685 was removed -- change it to wherever you wire
  the pan servo. Calibration needs that servo to scan for the goal.
- **HS-311 limits.** 120 degrees of travel, 575-2460 us, about
  3.0-3.7 kg.cm of torque. `servo_control.py` passes the 120 degree range
  to gpiozero; a 180 degree assumption would put every angle at the wrong
  pulse. On the bench, check that the panel sits facing forward at
  `SERVO_CENTER_DEG = 60`, that it moves the right direction (flip the
  sign if not), and that the panel and bracket are light enough for the
  torque. The stall-current figure in `config.py` is an estimate, not a
  datasheet value.
- **Reach.** With the 5 degree end-stop margins the panel normal can
  turn +-55 degrees. Since the normal is (ball + goal) / 2 and the camera
  sees ball bearings out to +-33 degrees, any goal within about +-77
  degrees of forward is fully covered. Goals further round (up to +-110)
  are only served for some ball directions, and beyond that the command
  is clamped at the end-stop, so the ball won't be sent accurately at
  the goal. If the goal can sit further round than that, the panel's
  mounting angle has to change (or a servo with more travel be used).
- The fusion settings (`FUSION_*`) only matter in `"fused"` mode and are
  untuned defaults.
- No obstacle/edge-case handling yet for the ball briefly leaving the
  frame mid-approach -- currently it just holds the last angle, which is
  a reasonable default but worth testing against real ball speeds.
- `main.py` transitions from calibration straight into the live trial
  with no manual prompt, per the competition's no-intervention rule --
  double check the calibration scan reliably finds the goal before
  relying on that in a real run.
