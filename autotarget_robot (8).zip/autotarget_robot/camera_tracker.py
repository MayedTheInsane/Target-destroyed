"""
Hybrid ball/goal tracking for the Raspberry Pi AI Camera (IMX500):

  * NN path  -- a detection model running ON the camera sensor
                (IMX500) returns bounding boxes for the ball / goal.
  * HSV path -- classic OpenCV color thresholding on the same frame,
                run on the Pi's CPU.

Current setup (config.py): the BALL uses the NN path with the stock COCO
model's "sports ball" class; the GOAL uses the HSV path. The fusion
modes described below are still available per target if you change
DETECTION_MODE_BALL / DETECTION_MODE_GOAL.

Both paths look at the same frame and report a pixel position; this
module combines them per target (ball, goal) according to
config.DETECTION_MODE_BALL / DETECTION_MODE_GOAL:

    "fused"    use both (default). If they agree (horizontal centers
               within FUSION_AGREE_TOL_FRAC of the frame width) the
               result is a weighted average and the source is "both".
               If only one fires, that one is used (fallback). If both
               fire but DISAGREE, config.FUSION_PRIMARY wins -- this is
               what filters out e.g. a yellow-green object that is not
               the ball, or an NN false positive.
    "nn_only"  NN path only.
    "hsv_only" HSV path only (no model needed).

If the NN model can't be loaded (missing file, bad firmware load, ...)
and a target is in "fused" mode, it silently degrades to HSV-only with
a loud warning, so a model problem never leaves the robot blind.

Interface used by main.py is unchanged from the NN-only version:

    cap = open_capture()
    frame, nn_detections = read_frame(cap)
    ball_bearing = get_ball_bearing(frame, nn_detections)
    goal_bearing = get_goal_bearing(frame, nn_detections)

Bearing convention: 0 deg = camera centerline, + = right, - = left.

Requires: picamera2, opencv-python, numpy.
The NN-output parsing in _parse_nn_detections() is modelled on the
official picamera2 IMX500 object-detection demo
(examples/imx500/imx500_object_detection_demo.py); if your trained
model's outputs differ, compare against that script on your Pi.
"""

import os
from collections import namedtuple

import cv2
import numpy as np

import config

# A single fused result for one target.
#   source: "nn", "hsv", "both"  (both agreed)
#           "nn*", "hsv*"        (both fired but disagreed; PRIMARY chosen)
Detection = namedtuple("Detection", ["cx", "cy", "source"])

_picam2 = None
_imx500 = None
_intrinsics = None
_nn_loaded = False        # model loaded successfully at open_capture()
_nn_parse_failed = False  # NN output parsing blew up at runtime
_ball_class_index = None  # NN class id of the ball, resolved at open_capture()

# Standard 80-class COCO list. Only used to find / display class names if the
# loaded model carries no label list of its own.
_COCO80 = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
    "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch",
    "potted plant", "bed", "dining table", "toilet", "tv", "laptop", "mouse",
    "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
    "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier",
    "toothbrush",
]


# ----------------------------------------------------------------------
# Camera / NN setup
# ----------------------------------------------------------------------
def _nn_wanted():
    return "hsv_only" != config.DETECTION_MODE_BALL or "hsv_only" != config.DETECTION_MODE_GOAL


def _nn_active():
    return _nn_loaded and not _nn_parse_failed


def _model_labels():
    """
    The loaded model's own label list, or None if it has none. COCO-style
    label files contain "-" placeholders for unused ids; picamera2's own
    demo drops them (when the model asks) before indexing, so do the same.
    """
    labels = getattr(_intrinsics, "labels", None) if _intrinsics is not None else None
    if labels and getattr(_intrinsics, "ignore_dash_labels", False):
        labels = [name for name in labels if name and name != "-"]
    return labels or None


def _resolve_ball_class_index():
    """
    Work out which NN class id is the ball. Returns (index, where_from).
    Uses config.IMX500_BALL_CLASS_INDEX if set; otherwise finds
    config.IMX500_BALL_LABEL in the model's labels (or the built-in COCO
    list when the model has none).
    """
    if config.IMX500_BALL_CLASS_INDEX is not None:
        return config.IMX500_BALL_CLASS_INDEX, "IMX500_BALL_CLASS_INDEX in config.py"

    labels = _model_labels()
    where = "the model's own labels"
    if labels is None:
        labels, where = _COCO80, "the built-in COCO list (the model has no labels)"

    wanted = config.IMX500_BALL_LABEL.strip().lower()
    for index, name in enumerate(labels):
        if str(name).strip().lower() == wanted:
            return index, where
    raise RuntimeError(
        f"Could not find the label {config.IMX500_BALL_LABEL!r} among the "
        f"{len(labels)} labels from {where}. Fix IMX500_BALL_LABEL in "
        "config.py, or set IMX500_BALL_CLASS_INDEX directly (run "
        "`python3 camera_tracker.py` with a ball in view to read its class number)."
    )


def ball_class_index():
    """The ball's NN class id (resolved at open_capture(), else config's value)."""
    return _ball_class_index if _ball_class_index is not None else config.IMX500_BALL_CLASS_INDEX


def open_capture():
    """
    Start the camera. If any target uses the NN, also load the model
    onto the IMX500 sensor (first load can take a while -- a progress
    bar is shown). Returns the Picamera2 instance.
    """
    global _picam2, _imx500, _intrinsics, _nn_loaded, _nn_parse_failed, _ball_class_index

    from picamera2 import Picamera2

    _nn_loaded = False
    _nn_parse_failed = False
    _imx500 = None
    _intrinsics = None
    _ball_class_index = None

    if _nn_wanted():
        try:
            from picamera2.devices import IMX500
            from picamera2.devices.imx500 import NetworkIntrinsics

            if not os.path.isfile(config.IMX500_MODEL_PATH):
                raise FileNotFoundError(config.IMX500_MODEL_PATH)

            _imx500 = IMX500(config.IMX500_MODEL_PATH)
            _intrinsics = _imx500.network_intrinsics
            if not _intrinsics:
                _intrinsics = NetworkIntrinsics()
                _intrinsics.task = "object detection"
            # Optional output-format overrides from config.py (None = keep the model's own).
            for attr, value in (("bbox_normalization", config.IMX500_BBOX_NORMALIZATION),
                                ("bbox_order", config.IMX500_BBOX_ORDER),
                                ("ignore_dash_labels", config.IMX500_IGNORE_DASH_LABELS)):
                if value is not None:
                    setattr(_intrinsics, attr, value)
            _nn_loaded = True
        except Exception as exc:  # noqa: BLE001 -- any load failure should degrade, not crash
            _imx500 = None
            print(f"[camera_tracker] WARNING: could not load IMX500 model ({exc!r}).")
            if "nn_only" in (config.DETECTION_MODE_BALL, config.DETECTION_MODE_GOAL):
                raise RuntimeError(
                    "A target is set to 'nn_only' in config.py but the NN model "
                    "could not be loaded -- fix IMX500_MODEL_PATH or change the mode."
                ) from exc
            print("[camera_tracker] Falling back to HSV-only detection for 'fused' targets.")

    if _nn_loaded and config.DETECTION_MODE_BALL != "hsv_only":
        _ball_class_index, where = _resolve_ball_class_index()
        print(f"[camera_tracker] Ball = {config.IMX500_BALL_LABEL!r} -> NN class "
              f"{_ball_class_index} (from {where}).")

    _picam2 = Picamera2(_imx500.camera_num) if _imx500 is not None else Picamera2()

    # "RGB888" in picamera2 gives numpy arrays in B,G,R byte order, i.e.
    # exactly what OpenCV expects -- so cv2.cvtColor(BGR2HSV) works as-is.
    cam_config = _picam2.create_preview_configuration(
        main={"size": (config.FRAME_WIDTH, config.FRAME_HEIGHT), "format": "RGB888"},
        controls={"FrameRate": config.LIVE_LOOP_HZ},
        buffer_count=6,
    )
    _picam2.configure(cam_config)
    if _imx500 is not None:
        _imx500.show_network_fw_progress_bar()
    _picam2.start()
    return _picam2


def read_frame(cap):
    """
    Grab one frame plus this frame's NN detections.

    Returns (frame, nn_detections):
      frame           BGR numpy array (H, W, 3)
      nn_detections   list of (class_index, confidence, (x, y, w, h)) with
                      the box in `frame` pixel coordinates; [] if the NN
                      is off/unavailable or saw nothing this frame.
    """
    request = cap.capture_request()
    try:
        frame = request.make_array("main")
        metadata = request.get_metadata()
    finally:
        request.release()

    if frame.ndim == 3 and frame.shape[2] == 4:
        frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)

    return frame, _parse_nn_detections(metadata, cap)


def _parse_nn_detections(metadata, picam2):
    """Turn raw IMX500 outputs into [(class_idx, conf, (x, y, w, h)), ...]."""
    global _nn_parse_failed

    if not _nn_active():
        return []

    try:
        outputs = _imx500.get_outputs(metadata, add_batch=True)
        if outputs is None:  # normal for the first few frames
            return []

        input_w, input_h = _imx500.get_input_size()
        threshold = config.IMX500_MIN_CONFIDENCE

        if getattr(_intrinsics, "postprocess", "") == "nanodet":
            from picamera2.devices.imx500 import postprocess_nanodet_detection
            from picamera2.devices.imx500.postprocess import scale_boxes

            boxes, scores, classes = postprocess_nanodet_detection(
                outputs=outputs[0], conf=threshold, iou_thres=0.65, max_out_dets=10
            )[0]
            boxes = scale_boxes(boxes, 1, 1, input_h, input_w, False, False)
        else:
            # "_pp" models (e.g. ssd_mobilenetv2_fpnlite_320x320_pp) return
            # already-decoded boxes / scores / classes.
            boxes, scores, classes = outputs[0][0], outputs[1][0], outputs[2][0]
            if getattr(_intrinsics, "bbox_normalization", False):
                boxes = boxes / input_h
            if getattr(_intrinsics, "bbox_order", "yx") == "xy":
                boxes = boxes[:, [1, 0, 3, 2]]
            boxes = zip(*np.array_split(boxes, 4, axis=1))

        detections = []
        for box, score, cls in zip(boxes, scores, classes):
            if score < threshold:
                continue
            x, y, w, h = (float(np.ravel(v)[0]) for v in
                          _imx500.convert_inference_coords(box, metadata, picam2))
            detections.append((int(cls), float(score), (x, y, w, h)))
        return detections

    except Exception as exc:  # noqa: BLE001
        _nn_parse_failed = True
        print(f"\n[camera_tracker] WARNING: NN output parsing failed ({exc!r}). "
              "Disabling the NN path for this run: 'fused' targets fall back to HSV, "
              "but any target set to 'nn_only' (the ball, by default) will now see "
              "NOTHING. Compare _parse_nn_detections() with picamera2's imx500 demo "
              "script, or try the IMX500_BBOX_* overrides in config.py.")
        return []


def nn_label(class_index):
    """Human-readable label for a class index (model labels, else the COCO list)."""
    labels = _model_labels() or _COCO80
    if class_index is not None and 0 <= class_index < len(labels):
        return labels[class_index]
    return f"class {class_index}"


# ----------------------------------------------------------------------
# NN path: best detection of a class -> (cx, cy)
# ----------------------------------------------------------------------
def _best_nn_point(nn_detections, class_index):
    best = None
    best_conf = -1.0
    for cls, conf, (x, y, w, h) in nn_detections or []:
        if cls == class_index and conf > best_conf:
            best_conf = conf
            best = (x + w / 2.0, y + h / 2.0)
    return best


# ----------------------------------------------------------------------
# HSV path: same color-blob logic as the original version
# ----------------------------------------------------------------------
def _largest_blob_centroid(mask):
    """(cx, cy, area) of the largest contour above the noise threshold, else None."""
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None

    largest = max(contours, key=cv2.contourArea)
    if cv2.contourArea(largest) < config.MIN_BLOB_AREA_PX:
        return None

    moments = cv2.moments(largest)
    if moments["m00"] == 0:
        return None
    return moments["m10"] / moments["m00"], moments["m01"] / moments["m00"], cv2.contourArea(largest)


def find_ball_hsv(frame_bgr):
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, config.TENNIS_BALL_HSV_LOW, config.TENNIS_BALL_HSV_HIGH)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    return _largest_blob_centroid(mask)


def find_goal_hsv(frame_bgr):
    """Handles hue wraparound (e.g. red) by OR-ing two HSV ranges."""
    hsv = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2HSV)
    mask1 = cv2.inRange(hsv, config.GOAL_HSV_LOW_1, config.GOAL_HSV_HIGH_1)
    mask2 = cv2.inRange(hsv, config.GOAL_HSV_LOW_2, config.GOAL_HSV_HIGH_2)
    mask = cv2.bitwise_or(mask1, mask2)
    mask = cv2.erode(mask, None, iterations=2)
    mask = cv2.dilate(mask, None, iterations=2)
    return _largest_blob_centroid(mask)


def _hsv_point(blob):
    return None if blob is None else (blob[0], blob[1])


# ----------------------------------------------------------------------
# Fusion
# ----------------------------------------------------------------------
def fuse(nn_pt, hsv_pt, mode, frame_width):
    """
    Combine the two detectors' (cx, cy) results (either may be None)
    according to `mode`. Returns a Detection or None. Pure function --
    no camera needed, so it can be unit-tested on a laptop.
    """
    if mode == "nn_only":
        return Detection(*nn_pt, "nn") if nn_pt else None
    if mode == "hsv_only":
        return Detection(*hsv_pt, "hsv") if hsv_pt else None

    # mode == "fused"
    if nn_pt and hsv_pt:
        tol_px = config.FUSION_AGREE_TOL_FRAC * frame_width
        if abs(nn_pt[0] - hsv_pt[0]) <= tol_px:
            w = config.FUSION_NN_WEIGHT
            return Detection(w * nn_pt[0] + (1 - w) * hsv_pt[0],
                             w * nn_pt[1] + (1 - w) * hsv_pt[1], "both")
        # Disagreement: trust the configured primary detector.
        if config.FUSION_PRIMARY == "hsv":
            return Detection(*hsv_pt, "hsv*")
        return Detection(*nn_pt, "nn*")
    if nn_pt:
        return Detection(*nn_pt, "nn")
    if hsv_pt:
        return Detection(*hsv_pt, "hsv")
    return None


def _effective_mode(mode):
    """'fused' degrades to HSV-only if the NN isn't usable right now."""
    if mode == "fused" and not _nn_active():
        return "hsv_only"
    return mode


def _detect(frame, nn_detections, mode, class_index, hsv_finder):
    mode = _effective_mode(mode)
    nn_pt = _best_nn_point(nn_detections, class_index) if mode in ("fused", "nn_only") else None
    hsv_pt = _hsv_point(hsv_finder(frame)) if mode in ("fused", "hsv_only") else None
    return fuse(nn_pt, hsv_pt, mode, frame.shape[1]), nn_pt, hsv_pt


def get_ball_detection(frame, nn_detections):
    return _detect(frame, nn_detections, config.DETECTION_MODE_BALL,
                   ball_class_index(), find_ball_hsv)[0]


def get_goal_detection(frame, nn_detections):
    return _detect(frame, nn_detections, config.DETECTION_MODE_GOAL,
                   config.IMX500_GOAL_CLASS_INDEX, find_goal_hsv)[0]


# ----------------------------------------------------------------------
# Pixel -> bearing (unchanged pinhole-linear approximation)
# ----------------------------------------------------------------------
def pixel_offset_to_bearing(cx: float, frame_width: int, hfov_deg: float) -> float:
    frame_center = frame_width / 2.0
    fraction_of_half_fov = (cx - frame_center) / frame_center
    return fraction_of_half_fov * (hfov_deg / 2.0)


def get_ball_bearing(frame, nn_detections):
    """Ball bearing in degrees, or None if not found this frame."""
    det = get_ball_detection(frame, nn_detections)
    if det is None:
        return None
    return pixel_offset_to_bearing(det.cx, frame.shape[1], config.CAMERA_HFOV_DEG)


def get_goal_bearing(frame, nn_detections):
    """Goal bearing in degrees, or None if not found this frame."""
    det = get_goal_detection(frame, nn_detections)
    if det is None:
        return None
    return pixel_offset_to_bearing(det.cx, frame.shape[1], config.CAMERA_HFOV_DEG)


# ----------------------------------------------------------------------
# Standalone test:  python3 camera_tracker.py [--preview]
#   Prints, per frame, what each detector sees and what fusion decided,
#   plus every raw NN detection with its class index + label. Hold the
#   tennis ball in view: if the NN column is empty or the label next to the
#   ball isn't "sports ball", that is the place to spot a wrong class
#   number or a model that can't see the ball (see IMX500_BALL_* in config.py).
#   --preview opens a window (works over VNC): green = NN boxes,
#   magenta = HSV centroids, white cross = fused result.
# ----------------------------------------------------------------------
def _fmt(pt_or_det):
    if pt_or_det is None:
        return "  -  "
    cx = pt_or_det.cx if isinstance(pt_or_det, Detection) else pt_or_det[0]
    return f"{cx:5.0f}"


if __name__ == "__main__":
    import sys

    preview = "--preview" in sys.argv
    cap = open_capture()
    print(f"NN active: {_nn_active()} | ball mode: {config.DETECTION_MODE_BALL} | "
          f"goal mode: {config.DETECTION_MODE_GOAL}")
    print("Ctrl+C (or 'q' in the preview window) to quit.")
    print("columns = x pixel: nn / hsv / fused[source]   |  raw NN detections")
    try:
        while True:
            frame, nn_dets = read_frame(cap)

            ball, ball_nn, ball_hsv = _detect(frame, nn_dets, config.DETECTION_MODE_BALL,
                                              ball_class_index(), find_ball_hsv)
            goal, goal_nn, goal_hsv = _detect(frame, nn_dets, config.DETECTION_MODE_GOAL,
                                              config.IMX500_GOAL_CLASS_INDEX, find_goal_hsv)

            raw = ", ".join(f"{c}:{nn_label(c)} {s:.2f}" for c, s, _ in nn_dets[:3]) or "none"
            line = (f"BALL {_fmt(ball_nn)}/{_fmt(ball_hsv)}/{_fmt(ball)}"
                    f"[{ball.source if ball else '-'}]  "
                    f"GOAL {_fmt(goal_nn)}/{_fmt(goal_hsv)}/{_fmt(goal)}"
                    f"[{goal.source if goal else '-'}]  | NN: {raw}")
            print(line.ljust(150), end="\r")

            if preview:
                view = frame.copy()
                for cls, conf, (x, y, w, h) in nn_dets:
                    cv2.rectangle(view, (int(x), int(y)), (int(x + w), int(y + h)), (0, 255, 0), 1)
                    cv2.putText(view, f"{nn_label(cls)} {conf:.2f}", (int(x), max(int(y) - 3, 10)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 0), 1)
                for pt in (ball_hsv, goal_hsv):
                    if pt:
                        cv2.circle(view, (int(pt[0]), int(pt[1])), 5, (255, 0, 255), 2)
                for det in (ball, goal):
                    if det:
                        cv2.drawMarker(view, (int(det.cx), int(det.cy)), (255, 255, 255),
                                       cv2.MARKER_CROSS, 14, 2)
                cv2.imshow("AutoTarget hybrid camera test", view)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
    except KeyboardInterrupt:
        pass
    finally:
        print("\nStopped.")
        cap.stop()
        if preview:
            cv2.destroyAllWindows()
